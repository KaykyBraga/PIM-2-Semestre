﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Verificador
    {
        public Verificador() { }

        public bool VerificarEmail(string email, out string mensagemErro)
        {
            mensagemErro = "";

            // Verifica o formato do e-mail
            string padraoEmail = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
            if (!Regex.IsMatch(email, padraoEmail, RegexOptions.IgnoreCase))
            {
                mensagemErro = "Formato de e-mail inválido.";
                return false;
            }

            // Verifica se o e-mail já está cadastrado
            foreach (var usuario in Usuario.emailUsuario)
            {
                if (usuario == email)
                {
                    mensagemErro = "Este e-mail já está cadastrado.";
                    return false;
                }
            }
            return true; // E-mail válido e ainda não cadastrado
        }

        public bool VerificarCpf(string cpf, out string mensagemErro)
        {
            mensagemErro = "";

            // Remove caracteres não numéricos
            cpf = new string(cpf.Where(char.IsDigit).ToArray());

            if (cpf.Length != 11)
            {
                mensagemErro = "O CPF deve conter 11 dígitos.";
                return false;
            }
            // Verifica se todos os dígitos são iguais (CPF inválido)
            if (cpf.Distinct().Count() == 1)
            {
                mensagemErro = "CPF inválido. Todos os dígitos são iguais.";
                return false;
            }
            // Calcula o primeiro dígito verificador
            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += (cpf[i] - '0') * (10 - i);

            int primeiroDigito = soma % 11;
            primeiroDigito = (primeiroDigito < 2) ? 0 : 11 - primeiroDigito;

            if ((cpf[9] - '0') != primeiroDigito)
            {
                mensagemErro = "CPF inválido.";
                return false;
            }

            // Calcula o segundo dígito verificador
            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += (cpf[i] - '0') * (11 - i);

            int segundoDigito = soma % 11;
            segundoDigito = (segundoDigito < 2) ? 0 : 11 - segundoDigito;

            if ((cpf[10] - '0') != segundoDigito)
            {
                mensagemErro = "CPF inválido.";
                return false;
            }

            // Verifica se o CPF já está cadastrado
            foreach (var usuario in Usuario.cpfUsuario)
            {
                if (usuario == cpf)
                {
                    mensagemErro = "Este CPF já está cadastrado.";
                    return false;
                }
            }
            return true; // CPF válido e ainda não cadastrado
        }

        public bool VerificarLivroExistente(string isbn, out int livro)
        {
            for (int i = 0; i < Livro.contadorLivros; i++)
            {
                if (Livro.isbnLivro[i] == isbn)
                {
                    livro = i;
                    return true; // Livro já cadastrado
                }
            }

            livro = -1; // Livro não encontrado
            return false; // Livro válido e ainda não cadastrado
        }
    }
}
