﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Livro
    {
        public static int max_livros = 1000;
        public static int[] idLivro = new int[max_livros];
        public static string[] isbnLivro = new string[max_livros];
        public static string[] tituloLivro = new string[max_livros];
        public static string[] autorLivro = new string[max_livros];
        public static string[] editoraLivro = new string[max_livros];
        public static string[] anoLivro = new string[max_livros];
        public static string[] generoLivro = new string[max_livros];
        public static int[] qtdVezesEmprestado = new int[max_livros];
        public static int[] qtdLivro = new int[max_livros];
        public static int contadorLivros;


        public static bool verificarDisponibilidade(string isbn, out int item)
        {
            for (int i = 0; i < contadorLivros; i++)
            {
                if (isbnLivro[i] == isbn)
                {
                    if (qtdLivro[i] > 0)
                    {
                        item = i;
                        return true;
                    }
                    else
                    {
                        item = 0;
                        return false;
                    }
                }
            }
            item = 0; // livro não encontrado
            return false;
        }
    }
}
