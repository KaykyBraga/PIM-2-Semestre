﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class CarregarDados
    {
        public CarregarDados() { }
        public void CarregarUsuarios()
        {
            string caminho = "usuarios.txt";
            // Verifica se o arquivo existe
            if (!File.Exists(caminho))
            {
                // Cria o arquivo vazio
                File.Create(caminho).Close(); // .Close() é necessário para liberar o arquivo
                Usuario.qtdUsuarios = 0;
                return;
            }

            string[] linhas = File.ReadAllLines("usuarios.txt");
            for (int i = 0; i < linhas.Length; i++)
            {
                string[] dados = linhas[i].Split(',');
                Usuario.idUsuario[i] = int.Parse(dados[0]);
                Usuario.nomeUsuario[i] = dados[1];
                Usuario.senhaUsuario[i] = dados[2];
                Usuario.emailUsuario[i] = dados[3];
                Usuario.telefoneUsuario[i] = dados[4];
                Usuario.cpfUsuario[i] = dados[5];
            }
            Usuario.qtdUsuarios = linhas.Length;
        }

        public void CarregarLivros()
        {
            string caminho = "livros.txt";

            // Verifica se o arquivo existe
            if (!File.Exists(caminho))
            {
                // Cria o arquivo vazio
                File.Create(caminho).Close(); // .Close() é necessário para liberar o arquivo
                Livro.contadorLivros = 0;
                return;
            }

            string[] linhas = File.ReadAllLines("livros.txt");
            for (int i = 0; i < linhas.Length; i++)
            {
                string[] dados = linhas[i].Split(',');
                Livro.idLivro[i] = int.Parse(dados[0]);
                Livro.isbnLivro[i] = dados[1];
                Livro.tituloLivro[i] = dados[2];
                Livro.autorLivro[i] = dados[3];
                Livro.editoraLivro[i] = dados[4];
                Livro.anoLivro[i] = dados[5];
                Livro.generoLivro[i] = dados[6];
                Livro.qtdLivro[i] = int.Parse(dados[7]);
                Livro.qtdVezesEmprestado[i] = int.Parse(dados[8]);
            }
            Livro.contadorLivros = linhas.Length;
        }

        public void CarregarEmprestimos()
        {
            string caminho = "emprestimos.txt";

            // Verifica se o arquivo existe
            if (!File.Exists(caminho))
            {
                // Cria o arquivo vazio
                File.Create(caminho).Close(); // .Close() é necessário para liberar o arquivo
                Emprestimos.contadorEmprestimos = 0;
                return;
            }


            string[] linhas = File.ReadAllLines("emprestimos.txt");
            for (int i = 0; i < linhas.Length; i++)
            {
                string[] dados = linhas[i].Split(',');
                Emprestimos.idEmprestimo[i] = int.Parse(dados[0]);
                Emprestimos.cpfUsuarioEmp[i] = dados[1];
                Emprestimos.isbnLivroEmp[i] = dados[2];
                Emprestimos.dataEmprestimo[i] = DateTime.Parse(dados[3]);
                Emprestimos.dataDevolucaoPrevista[i] = DateTime.Parse(dados[4]);
                Emprestimos.dataDevolucaoReal[i] = DateTime.Parse(dados[5]);
                Emprestimos.statusEmprestimo[i] = int.Parse(dados[6]);
            }
            Emprestimos.contadorEmprestimos = linhas.Length;
        }
    }
}
