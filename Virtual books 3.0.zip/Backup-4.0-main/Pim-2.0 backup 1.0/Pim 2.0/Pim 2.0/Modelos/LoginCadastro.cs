﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class LoginCadastro
    {
        public LoginCadastro() { }
        public void CriarContaUsuario(string nome, string senha, string email, string telefone, string cpf, out string mensagemErro, out int erro)
        {
            SalvarDados salvar = new SalvarDados();
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarUsuarios();
            Verificador verificar = new Verificador();

            if (verificar.VerificarEmail(email, out string mensagemErro1)) // ela ja verifica se o email é valido e se ja foi cadastrado
            {
                if (verificar.VerificarCpf(cpf, out string mensagemErro2)) // ela ja verifica se o cpf é valido e se ja foi cadastrado
                {
                    Usuario.emailUsuario[Usuario.qtdUsuarios] = email;
                    Usuario.cpfUsuario[Usuario.qtdUsuarios] = cpf;
                }
                else
                {
                    erro = 2;
                    mensagemErro = mensagemErro2;
                    return;
                }
            }
            else
            {
                erro = 1;
                mensagemErro = mensagemErro1;
                return;
            }



            Usuario.idUsuario[Usuario.qtdUsuarios] = Usuario.qtdUsuarios + 1;
            Usuario.nomeUsuario[Usuario.qtdUsuarios] = nome;
            Usuario.senhaUsuario[Usuario.qtdUsuarios] = senha;
            Usuario.telefoneUsuario[Usuario.qtdUsuarios] = telefone;
            Usuario.qtdUsuarios++; // Incrementa a quantidade de usuários cadastrados
            salvar.SalvarUsuario(); // Salva os dados no arquivo
            mensagemErro = "Cadastro concluído com sucesso!";
            erro = 0;
            return;

        }

        public bool LoginBibliotecario(string email, string senha)
        {
            if (Bibliotecario.Email == email && Bibliotecario.Senha == senha)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public void LoginUsuario(string cpfOuEmail, string senha, out int tela)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarUsuarios();

            for (int i = 0; i < Usuario.qtdUsuarios; i++)
            {
                if (Usuario.emailUsuario[i] == cpfOuEmail && Usuario.senhaUsuario[i] == senha)
                {
                    // Aqui adicionar a tela para onde o usuario vai
                    tela = 1;
                    return;
                }

            }
            if (LoginBibliotecario(cpfOuEmail, senha))
            {
                // Aqui adicionar a tela para onde o bibliotecario vai
                tela = 2;
                return;
            }
            tela = 3;
            return;

        }

        public void RedefinirSenha(string cpf, string email, string telefone, string senha, string confirmacaoSenha)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarUsuarios();
            for (int i = 0; i < Usuario.qtdUsuarios; i++)
            {
                if (Usuario.cpfUsuario[i] == cpf && Usuario.emailUsuario[i] == email && Usuario.telefoneUsuario[i] == telefone)
                {
                    if (senha == confirmacaoSenha)
                    {
                        Usuario.senhaUsuario[i] = senha;
                        SalvarDados salvar = new SalvarDados();
                        salvar.SalvarUsuario();
                        MessageBox.Show("Senha redefinida com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                    else
                    {
                        MessageBox.Show("As senhas não coincidem.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }
            MessageBox.Show("Cpf, email ou telefone estão incorretos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
    }

}
