﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class SalvarDados
    {
        // Dar um jeito de salvar o usuários em uma pasta
        public SalvarDados() { }

        public void SalvarUsuario()
        {

            string[] linhas = new string[Usuario.qtdUsuarios];

            for (int i = 0; i < Usuario.qtdUsuarios; i++)
            {
                linhas[i] = $"{Usuario.idUsuario[i].ToString()},{Usuario.nomeUsuario[i]},{Usuario.senhaUsuario[i]}," +
                    $"{Usuario.emailUsuario[i]},{Usuario.telefoneUsuario[i]},{Usuario.cpfUsuario[i]}";
            }
            File.WriteAllLines("usuarios.txt", linhas);
        }

        public void SalvarLivros()
        {
            string[] linhas = new string[Livro.contadorLivros];
            for (int i = 0; i < Livro.contadorLivros; i++)
            {
                linhas[i] = $"{Livro.idLivro[i].ToString()},{Livro.isbnLivro[i]},{Livro.tituloLivro[i]}," +
                    $"{Livro.autorLivro[i]},{Livro.editoraLivro[i]},{Livro.anoLivro[i]},{Livro.generoLivro[i]}," +
                    $"{Livro.qtdLivro[i]},{Livro.qtdVezesEmprestado[i]}";
            }
            File.WriteAllLines("livros.txt", linhas);
        }

        public void SalvarEmprestimos()
        {
            string[] linhas = new string[Emprestimos.contadorEmprestimos];
            for (int i = 0; i < Emprestimos.contadorEmprestimos; i++)
            {
                linhas[i] = $"{Emprestimos.idEmprestimo[i].ToString()},{Emprestimos.cpfUsuarioEmp[i]}," +
                    $"{Emprestimos.isbnLivroEmp[i]},{Emprestimos.dataEmprestimo[i].ToString()}," +
                    $"{Emprestimos.dataDevolucaoPrevista[i].ToString()},{Emprestimos.dataDevolucaoReal[i].ToString()},{Emprestimos.statusEmprestimo[i].ToString()}";
            }
            File.WriteAllLines("emprestimos.txt", linhas);
        }
    }
}
