namespace Pim_2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblEntrar_Click(object sender, EventArgs e)
        {
            Tela_Login tela_Login = new Tela_Login();
            tela_Login.Show();
            this.Hide();
        }

        private void lblCadastrar_Click(object sender, EventArgs e)
        {
            Tela_Cadastro tela_Cadastro = new Tela_Cadastro();
            tela_Cadastro.Show();
            this.Hide();
        }
    }
}
