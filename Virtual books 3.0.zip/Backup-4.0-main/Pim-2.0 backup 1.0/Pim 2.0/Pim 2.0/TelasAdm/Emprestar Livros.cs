﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Emprestar_Livros : Form
    {
        public Emprestar_Livros()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Hide();
        }

        private void btnEmprestar_Click(object sender, EventArgs e)
        {
            Bibliotecario bibliotecario = new Bibliotecario();
            if (!string.IsNullOrEmpty(txtCPF.Text) && !string.IsNullOrEmpty(txtIsbn.Text))
            {
                bibliotecario.EmprestarLivro(txtIsbn.Text, txtCPF.Text, out int erro);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Empréstimo realizado com sucesso.","Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case 1:
                        MessageBox.Show("Usuario não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 2:
                        MessageBox.Show("Limite de Emprestimos atingido.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 3:
                        MessageBox.Show("Livro não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }

            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
