﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pim_2._0.TelasUsuario
{
    public partial class LogadoUsuario : Form
    {
        public LogadoUsuario()
        {
            InitializeComponent();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            PerfilUsuario perfilUsuario = new PerfilUsuario();
            perfilUsuario.Show();
            this.Hide();
        }
    }
}
