﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0
{
    public partial class Tela_Cadastro : Form
    {
        public Tela_Cadastro()
        {
            InitializeComponent();
        }

        private void Tela_Cadastro_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginCadastro loginCadastro = new LoginCadastro();
            txtCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;// Remove the mask
            if (!string.IsNullOrEmpty(txtCPF.Text) && !string.IsNullOrEmpty(txtCSenha.Text) && !string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txtNome.Text) && !string.IsNullOrEmpty(txtSenha.Text) && !string.IsNullOrEmpty(txtTelefone.Text))
            {
                loginCadastro.CriarContaUsuario(txtNome.Text, txtSenha.Text, txtEmail.Text, txtTelefone.Text, txtCPF.Text, out string mensagemErro, out int erro);
                if (txtSenha.Text == txtCSenha.Text)
                {
                    switch (erro)
                    {
                        case 0:
                            MessageBox.Show(mensagemErro, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Tela_Login tela_Login = new Tela_Login();
                            tela_Login.Show();
                            this.Hide();
                            break;
                        case 1:
                            MessageBox.Show(mensagemErro, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                        case 2:
                            MessageBox.Show(mensagemErro, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                }
                else
                {
                    MessageBox.Show("As senhas não coincidem, tente novamente!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

        }

        private void chkMostrarSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarSenha.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
                txtCSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
                txtCSenha.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
}
