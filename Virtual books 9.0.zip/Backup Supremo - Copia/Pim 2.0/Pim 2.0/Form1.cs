using Pim_2._0.Modelos;

namespace Pim_2._0
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblEntrar_Click(object sender, EventArgs e)
        {
            this.Hide();
            var login = new Tela_Login();
            login.FormClosed += (s, args) => Application.Exit();
            login.Show();
        }

        private void lblCadastrar_Click(object sender, EventArgs e)
        {
            this.Hide();
            var cadastro = new Tela_Cadastro();
            cadastro.FormClosed += (s, args) => Application.Exit();
            cadastro.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controleBibliotecario = new ControleBibliotecario();
        }
    }
}
