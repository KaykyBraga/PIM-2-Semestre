﻿namespace Pim_2._0.TelasUsuario
{
    partial class LogadoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogadoUsuario));
            label1 = new Label();
            pictureBox6 = new PictureBox();
            panel1 = new Panel();
            label3 = new Label();
            label2 = new Label();
            comboBoxCategoria = new ComboBox();
            txtPesquisar = new TextBox();
            flowLayoutPanelLivros = new FlowLayoutPanel();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Silver;
            label1.Location = new Point(458, 36);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 10;
            label1.Text = "VirtualBooks";
            label1.Click += label1_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Cursor = Cursors.Hand;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(1012, 21);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(46, 44);
            pictureBox6.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox6.TabIndex = 17;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(comboBoxCategoria);
            panel1.Controls.Add(txtPesquisar);
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 18;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.DarkGray;
            label3.Location = new Point(200, 29);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 25;
            label3.Text = "Categoria";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.DarkGray;
            label2.Location = new Point(21, 29);
            label2.Name = "label2";
            label2.Size = new Size(59, 15);
            label2.TabIndex = 24;
            label2.Text = "Pesquisa :";
            // 
            // comboBoxCategoria
            // 
            comboBoxCategoria.FormattingEnabled = true;
            comboBoxCategoria.Location = new Point(200, 52);
            comboBoxCategoria.Name = "comboBoxCategoria";
            comboBoxCategoria.Size = new Size(181, 23);
            comboBoxCategoria.TabIndex = 23;
            comboBoxCategoria.SelectedIndexChanged += comboBoxCategoria_SelectedIndexChanged;
            // 
            // txtPesquisar
            // 
            txtPesquisar.Location = new Point(12, 52);
            txtPesquisar.Name = "txtPesquisar";
            txtPesquisar.Size = new Size(182, 23);
            txtPesquisar.TabIndex = 22;
            txtPesquisar.TextChanged += txtPesquisar_TextChanged;
            // 
            // flowLayoutPanelLivros
            // 
            flowLayoutPanelLivros.AutoScroll = true;
            flowLayoutPanelLivros.Dock = DockStyle.Bottom;
            flowLayoutPanelLivros.Location = new Point(0, 125);
            flowLayoutPanelLivros.Name = "flowLayoutPanelLivros";
            flowLayoutPanelLivros.Size = new Size(1079, 527);
            flowLayoutPanelLivros.TabIndex = 19;
            flowLayoutPanelLivros.Paint += flowLayoutPanelLivros_Paint;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(495, 90);
            label4.Name = "label4";
            label4.Size = new Size(71, 30);
            label4.TabIndex = 27;
            label4.Text = "Livros";
            // 
            // LogadoUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(label4);
            Controls.Add(flowLayoutPanelLivros);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "LogadoUsuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "LogadoUsuario";
            Load += LogadoUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private PictureBox pictureBox6;
        private Panel panel1;
        private FlowLayoutPanel flowLayoutPanelLivros;
        private Label label4;
        private Label label3;
        private Label label2;
        private ComboBox comboBoxCategoria;
        private TextBox txtPesquisar;
    }
}