﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;
using Pim_2._0.TelasAdm;
using Pim_2._0.TelasUsuario;

namespace Pim_2._0
{
    public partial class Tela_Login : Form
    {
        public Tela_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ControleUsuario controleLogin = new ControleUsuario();
            if (!string.IsNullOrEmpty(txtEmail.Text.Trim()) && !string.IsNullOrEmpty(txtSenha.Text.Trim()))
            {
                var login = controleLogin.Login(txtEmail.Text.Trim(), txtSenha.Text.Trim());
                switch (login)
                {
                    case 1:
                        MessageBox.Show("Login realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Usuario.EmailLogado = txtEmail.Text.Trim();
                        this.Hide();
                        var telaUsuario = new LogadoUsuario();
                        telaUsuario.FormClosed += (s, args) => Application.Exit();
                        telaUsuario.Show();
                        break;
                    case 2:
                        MessageBox.Show("Bem vindo Bibliotecario!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        var logadoBibliotecario = new Principal();
                        logadoBibliotecario.FormClosed += (s, args) => Application.Exit();
                        logadoBibliotecario.Show();
                        break;
                    case 3:
                        MessageBox.Show("Senha ou Email incorreto!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void chkMostrarSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarSenha.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var principal = new Form1();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void label5_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            var redefinir = new TelaRedefinir();
            redefinir.FormClosed += (s, args) => Application.Exit();
            redefinir.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
