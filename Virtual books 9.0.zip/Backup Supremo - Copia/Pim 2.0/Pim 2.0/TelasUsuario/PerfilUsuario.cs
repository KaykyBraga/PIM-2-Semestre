﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasUsuario
{
    public partial class PerfilUsuario : Form
    {

        public PerfilUsuario()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            LogadoUsuario logadoUsuario = new LogadoUsuario();
            this.Hide();
            logadoUsuario.FormClosed += (s, args) => Application.Exit();
            logadoUsuario.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.FormClosed += (s, args) => Application.Exit();
            form1.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void PerfilUsuario_Load(object sender, EventArgs e)
        {
            ControleUsuario controleUsuario = new ControleUsuario();
            // Obter o histórico do usuário via método da classe Bibliotecario
            var historico = controleUsuario.HistoricoUsuario(Usuario.EmailLogado);

            // Limpar o DataGridView antes de preencher
            dgvHistorico.Rows.Clear();

            // Preencher o DataGridView com os dados do histórico
            foreach (var item in historico)
            {
                int rowIndex = dgvHistorico.Rows.Add(
                    item.Titulo,
                    item.Isbn,
                    item.DataEmprestimo,
                    item.DataDevolucaoPrevista,
                    item.DataDevolucaoReal,
                    item.Status,
                    item.Multa
                );

                var row = dgvHistorico.Rows[rowIndex];

                // Ajustar cores conforme status
                if (item.Status == "Devolvido")
                    row.Cells[5].Style.BackColor = Color.LightGreen;
                else if (item.Status == "Ativo")
                    row.Cells[5].Style.BackColor = Color.LightGoldenrodYellow;
                else if (item.Status == "Atrasado")
                    row.Cells[5].Style.BackColor = Color.Red;

                // Cor da multa
                if (item.Multa != "Sem multa")
                    row.Cells[6].Style.BackColor = Color.LightYellow;
            }
        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
