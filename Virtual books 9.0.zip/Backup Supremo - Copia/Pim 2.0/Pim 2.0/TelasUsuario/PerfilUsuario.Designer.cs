﻿namespace Pim_2._0.TelasUsuario
{
    partial class PerfilUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PerfilUsuario));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            button1 = new Button();
            dgvHistorico = new DataGridView();
            Titulo = new DataGridViewTextBoxColumn();
            ISBN = new DataGridViewTextBoxColumn();
            DataEmprestimo = new DataGridViewTextBoxColumn();
            DataPrevista = new DataGridViewTextBoxColumn();
            DataDevolucao = new DataGridViewTextBoxColumn();
            StatusEmprestimo = new DataGridViewTextBoxColumn();
            Multa = new DataGridViewTextBoxColumn();
            label2 = new Label();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvHistorico).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Silver;
            label1.Location = new Point(458, 36);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 11;
            label1.Text = "VirtualBooks";
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(14, 16);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(67, 53);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.Cursor = Cursors.Hand;
            button1.Location = new Point(927, 25);
            button1.Name = "button1";
            button1.Size = new Size(140, 35);
            button1.TabIndex = 23;
            button1.Text = "Sair da Conta";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dgvHistorico
            // 
            dgvHistorico.AllowUserToAddRows = false;
            dgvHistorico.AllowUserToDeleteRows = false;
            dgvHistorico.AllowUserToResizeColumns = false;
            dgvHistorico.AllowUserToResizeRows = false;
            dgvHistorico.BackgroundColor = SystemColors.Control;
            dgvHistorico.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvHistorico.Columns.AddRange(new DataGridViewColumn[] { Titulo, ISBN, DataEmprestimo, DataPrevista, DataDevolucao, StatusEmprestimo, Multa });
            dgvHistorico.Location = new Point(186, 197);
            dgvHistorico.Name = "dgvHistorico";
            dgvHistorico.ReadOnly = true;
            dgvHistorico.Size = new Size(710, 343);
            dgvHistorico.TabIndex = 24;
            // 
            // Titulo
            // 
            Titulo.HeaderText = "Título";
            Titulo.Name = "Titulo";
            Titulo.ReadOnly = true;
            Titulo.Width = 180;
            // 
            // ISBN
            // 
            ISBN.HeaderText = "ISBN";
            ISBN.Name = "ISBN";
            ISBN.ReadOnly = true;
            ISBN.Width = 87;
            // 
            // DataEmprestimo
            // 
            DataEmprestimo.HeaderText = "Data Emprestimo";
            DataEmprestimo.Name = "DataEmprestimo";
            DataEmprestimo.ReadOnly = true;
            DataEmprestimo.Width = 75;
            // 
            // DataPrevista
            // 
            DataPrevista.HeaderText = "Data Prevista";
            DataPrevista.Name = "DataPrevista";
            DataPrevista.ReadOnly = true;
            DataPrevista.Width = 75;
            // 
            // DataDevolucao
            // 
            DataDevolucao.HeaderText = "Data Devolução";
            DataDevolucao.Name = "DataDevolucao";
            DataDevolucao.ReadOnly = true;
            DataDevolucao.Width = 75;
            // 
            // StatusEmprestimo
            // 
            StatusEmprestimo.HeaderText = "Status Emprestimo";
            StatusEmprestimo.Name = "StatusEmprestimo";
            StatusEmprestimo.ReadOnly = true;
            StatusEmprestimo.Width = 75;
            // 
            // Multa
            // 
            Multa.HeaderText = "Multa";
            Multa.Name = "Multa";
            Multa.ReadOnly = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(413, 117);
            label2.Name = "label2";
            label2.Size = new Size(264, 30);
            label2.TabIndex = 28;
            label2.Text = "Histórico de Empréstimos";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 29;
            // 
            // PerfilUsuario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(dgvHistorico);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "PerfilUsuario";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "PerfilUsuario";
            Load += PerfilUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvHistorico).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button button1;
        private DataGridView dgvHistorico;
        private DataGridViewTextBoxColumn Titulo;
        private DataGridViewTextBoxColumn ISBN;
        private DataGridViewTextBoxColumn DataEmprestimo;
        private DataGridViewTextBoxColumn DataPrevista;
        private DataGridViewTextBoxColumn DataDevolucao;
        private DataGridViewTextBoxColumn StatusEmprestimo;
        private DataGridViewTextBoxColumn Multa;
        private Label label2;
        private Panel panel1;
    }
}