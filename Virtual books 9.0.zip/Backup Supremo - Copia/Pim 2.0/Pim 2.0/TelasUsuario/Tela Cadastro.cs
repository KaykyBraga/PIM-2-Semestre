﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;
using Pim_2._0.TelasUsuario;

namespace Pim_2._0
{
    public partial class Tela_Cadastro : Form
    {
        public Tela_Cadastro()
        {
            InitializeComponent();
        }

        private void Tela_Cadastro_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                txtCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals; // Remove a máscara para pegar apenas os números
                ControleUsuario controleCadastro = new ControleUsuario();

                // Validação de campos vazios
                if (string.IsNullOrWhiteSpace(txtCPF.Text) ||
                    string.IsNullOrWhiteSpace(txtCSenha.Text) ||
                    string.IsNullOrWhiteSpace(txtEmail.Text) ||
                    string.IsNullOrWhiteSpace(txtNome.Text) ||
                    string.IsNullOrWhiteSpace(txtSenha.Text) ||
                    string.IsNullOrWhiteSpace(txtTelefone.Text))
                {
                    MessageBox.Show("Por favor, preencha todos os campos.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validação de senha e confirmação
                if (txtSenha.Text != txtCSenha.Text)
                {
                    MessageBox.Show("As senhas não coincidem, tente novamente!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Tentativa de criar conta
                bool sucesso = controleCadastro.CriarConta(txtNome.Text.Trim(), txtSenha.Text.Trim(), txtEmail.Text.Trim(), txtTelefone.Text.Trim(), txtCPF.Text.Trim(), out string mensagemErro);

                if (sucesso)
                {
                    MessageBox.Show(mensagemErro, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    LogadoUsuario logadoUsuario = new LogadoUsuario();
                    logadoUsuario.FormClosed += (s, args) => Application.Exit();
                    logadoUsuario.Show();
                }
                else
                {
                    MessageBox.Show(mensagemErro, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro inesperado:\n{ex.Message}", "Erro crítico", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void chkMostrarSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarSenha.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
                txtCSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
                txtCSenha.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var principal = new Form1();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
