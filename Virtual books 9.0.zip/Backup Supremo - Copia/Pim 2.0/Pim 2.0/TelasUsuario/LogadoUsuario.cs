﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasUsuario
{
    public partial class LogadoUsuario : Form
    {
        public LogadoUsuario()
        {
            InitializeComponent();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            PerfilUsuario perfilUsuario = new PerfilUsuario();
            this.Hide();
            perfilUsuario.FormClosed += (s, args) => Application.Exit();
            perfilUsuario.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LogadoUsuario_Load(object sender, EventArgs e)
        {
            string caminhoPlaceholder = Path.Combine(Application.StartupPath, "Recursos", "placeholder.jpg");

            flowLayoutPanelLivros.Controls.Clear();
            ControleUsuario controleUsuario = new ControleUsuario();
            List<(string Titulo, string Isbn, int Quantidade, string genero, string LinkCapa)> livros = controleUsuario.ObterLivrosParaExibicao();
            foreach (var livro in livros)
            {
                Panel card = new Panel
                {
                    Width = 190,
                    Height = 300,
                    BackColor = Color.DarkSlateBlue,
                    Margin = new Padding(10),
                    BorderStyle = BorderStyle.FixedSingle,
                    Tag = livro.genero
                };

                PictureBox pic = new PictureBox
                {
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Width = 180,
                    Height = 150,
                    Location = new Point(5, 10),
                    Image = Image.FromFile(caminhoPlaceholder)
                };

                if (!string.IsNullOrEmpty(livro.LinkCapa))
                {
                    Task.Run(() =>
                    {
                        try
                        {
                            using var webClient = new System.Net.WebClient();
                            byte[] imageBytes = webClient.DownloadData(livro.LinkCapa);
                            using var ms = new MemoryStream(imageBytes);
                            Image img = Image.FromStream(ms);
                            pic.Invoke((MethodInvoker)(() => pic.Image = img));
                        }
                        catch
                        {
                            // falha ao carregar imagem externa, fica com a placeholder
                        }
                    });
                }

                Label titulo = new Label
                {
                    Text = livro.Titulo,
                    Font = new Font("Arial", 9, FontStyle.Bold),
                    ForeColor = Color.Silver,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Width = 180,
                    Height = 40,
                    Location = new Point(5, 170)
                };

                Label isbn = new Label
                {
                    Text = "ISBN: " + livro.Isbn,
                    Font = new Font("Arial", 8),
                    ForeColor = Color.Silver,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Width = 180,
                    Height = 30,
                    Location = new Point(5, 210)
                };

                Label status = new Label
                {
                    Text = livro.Quantidade > 0 ? "Disponível" : "Indisponível",
                    BackColor = livro.Quantidade > 0 ? Color.LightGreen : Color.LightCoral,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Width = 170,
                    Height = 30,
                    Location = new Point(10, 250)
                };

                card.Controls.Add(pic);
                card.Controls.Add(titulo);
                card.Controls.Add(isbn);
                card.Controls.Add(status);

                flowLayoutPanelLivros.Controls.Add(card);

                if (!comboBoxCategoria.Items.Contains(livro.genero))
                {
                    comboBoxCategoria.Items.Add(livro.genero);
                }

            }
            comboBoxCategoria.DropDownStyle = ComboBoxStyle.DropDown;
            comboBoxCategoria.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBoxCategoria.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboBoxCategoria.Items.Insert(0, "Todos");
            comboBoxCategoria.SelectedIndex = 0;
        }

        private void FiltrarPorGenero(string genero)
        {
            foreach (Control card in flowLayoutPanelLivros.Controls)
            {
                if (card is Panel panel)
                {
                    string generoCard = panel.Tag?.ToString();
                    bool mostrar = string.IsNullOrWhiteSpace(genero) || genero == "Todos" || generoCard == genero;
                    panel.Visible = mostrar;
                }
            }
        }
        private void comboBoxCategoria_SelectedIndexChanged(object sender, EventArgs e)
        {
            string generoSelecionado = comboBoxCategoria.Text?.Trim();
            FiltrarPorGenero(generoSelecionado);
        }

        private void txtPesquisar_TextChanged(object sender, EventArgs e)
        {
            string termoBusca = txtPesquisar.Text.Trim().ToLower();

            foreach (Control item in flowLayoutPanelLivros.Controls)
            {

                Label lbl = item.Controls.OfType<Label>().FirstOrDefault();

                if (lbl != null)
                {
                    // Mostra se o texto do Label contém o termo
                    item.Visible = lbl.Text.ToLower().Contains(termoBusca);
                }
                else
                {
                    item.Visible = true; // Se não tiver Label, mantém visível
                }
            }
        }

        private void flowLayoutPanelLivros_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
