﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0
{
    public partial class TelaRedefinir : Form
    {
        public TelaRedefinir()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            var telaLogin = new Tela_Login();
            telaLogin.FormClosed += (s, args) => Application.Exit();
            telaLogin.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            ControleUsuario controleRedefinir = new ControleUsuario();
            txbCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;// Remove the mask


            if (!string.IsNullOrEmpty(txbCPF.Text.Trim()) && !string.IsNullOrEmpty(txtEmail.Text.Trim()) && !string.IsNullOrEmpty(txbTelefone.Text.Trim()) && !string.IsNullOrEmpty(txtSenha.Text.Trim()) && !string.IsNullOrEmpty(txtCSenha.Text.Trim()))
            {
                var erro = controleRedefinir.RedefinirSenha(txbCPF.Text.Trim(), txtEmail.Text.Trim(), txbTelefone.Text.Trim(), txtSenha.Text.Trim(), txtCSenha.Text.Trim());
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Senha redefinida com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        var telaLogin = new Tela_Login();
                        telaLogin.FormClosed += (s, args) => Application.Exit();
                        telaLogin.Show();
                        break;

                    case 1:
                        MessageBox.Show("As senhas não coincidem.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    case 2:
                        MessageBox.Show("Cpf, email ou telefone estão incorretos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
                txtCSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
                txtCSenha.UseSystemPasswordChar = true;
            }
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void txbCPF_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }
    }
}
