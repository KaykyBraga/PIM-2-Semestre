﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class ControleBibliotecario
    {
        private Bibliotecario bibliotecario;
        private Relatorios relatorios;

        public ControleBibliotecario()
        {
            CarregarDados carregar = new CarregarDados();
            var livros = carregar.CarregarLivros();
            var usuarios = carregar.CarregarUsuarios();
            var emprestimos = carregar.CarregarEmprestimos();
            bibliotecario = new Bibliotecario(livros, usuarios, emprestimos);
            relatorios = new Relatorios(livros, usuarios, emprestimos);
        }

        public bool AdicionarLivro(string isbn, string titulo, string autor, string editora, string ano, string genero, string qtdlivro, string capa, out string mensagem)
        {
            bibliotecario.AddLivro(isbn, titulo, autor, editora, ano, genero, qtdlivro, capa, out int erro);

            switch (erro)
            {
                case 0:
                    mensagem = "Livro cadastrado com sucesso!";
                    return true;
                case 1:
                    mensagem = "Já existe um livro com esse ISBN.";
                    return false;
                case 2:
                    mensagem = "Quantidade inválida.";
                    return false;
                default:
                    mensagem = "Erro desconhecido.";
                    return false;
            }
        }

        public bool AumentarEstoque(string isbn, string quantidade, out string mensagem)
        {
            bibliotecario.AumentarLivros(isbn, quantidade, out int erro);

            switch (erro)
            {
                case 0:
                    mensagem = "Estoque aumentado com sucesso!";
                    return true;
                case 1:
                    mensagem = "Quantidade inválida.";
                    return false;
                case 2:
                    mensagem = "Livro não encontrado.";
                    return false;
                default:
                    mensagem = "Erro desconhecido.";
                    return false;
            }
        }

        public bool RemoverEstoque(string isbn, string quantidade, out string mensagem)
        {
            bibliotecario.RemoverLivro(isbn, quantidade, out int erro);

            switch (erro)
            {
                case 0:
                    mensagem = "Quantidade removida com sucesso!";
                    return true;
                case 1:
                    mensagem = "Quantidade inválida.";
                    return false;
                case 2:
                    mensagem = "Quantidade maior que disponível.";
                    return false;
                case 3:
                    mensagem = "Livro não encontrado.";
                    return false;
                default:
                    mensagem = "Erro desconhecido.";
                    return false;
            }
        }

        public bool RealizarEmprestimo(string isbn, string cpf, out string mensagem)
        {
            bibliotecario.EmprestarLivro(isbn, cpf, out int erro);

            switch (erro)
            {
                case 0:
                    mensagem = "Empréstimo realizado com sucesso!";
                    return true;
                case 1:
                    mensagem = "Usuário não encontrado.";
                    return false;
                case 2:
                    mensagem = "Usuário atingiu o limite de empréstimos ativos.";
                    return false;
                case 3:
                    mensagem = "Livro não disponível ou não encontrado.";
                    return false;
                default:
                    mensagem = "Erro desconhecido.";
                    return false;
            }
        }

        public bool RealizarDevolucao(string isbn, string cpf, out string mensagem, out decimal multa)
        {
            bibliotecario.DevolverLivro(isbn, cpf, out int erro, out multa);

            switch (erro)
            {
                case 0:
                    mensagem = "Livro devolvido sem multa.";
                    return true;
                case 1:
                    mensagem = "Empréstimo não encontrado.";
                    return false;
                case 2:
                    mensagem = $"Livro devolvido com multa de R$ {multa:F2}.";
                    return true;
                default:
                    mensagem = "Erro desconhecido.";
                    return false;
            }
        }

        public async Task<(bool encontrado, string titulo, string autor, string editora, string ano, string genero, string capaUrl, string mensagem)> BuscarLivro(string isbn)
        {
            var buscar = await bibliotecario.BuscarLivroPorIsbnAsync(isbn);
            return buscar;
        }
        
        public List<(string titulo, string autor, string genero, int quantidade, string isbn, string disponibilidade)> RelatorioEstoque()
        {
            var relatorio = relatorios.GerarRelatorioEstoque();
            return relatorio;
        }

        public List<(string Ranking, string Titulo, string Autor, string Genero, string Isbn, int QtdEmprestimos)> RelatorioLivrosMaisEmprestados()
        {
            var relatorio = relatorios.GerarRelatorioLivrosMaisEmprestados();
            return relatorio;
        }

        public List<(string Nome, string Telefone, string Cpf, string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoPrevista, string Status, string Multa)> RelatorioEmprestimosAtrasados()
        {
            var relatorio = relatorios.GerarRelatorioEmprestimosAtrasados();
            return relatorio;
        }

        public List<(string Nome, string Telefone, string Cpf, string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoReal, string DataDevolucaoPrevista, string Status, string Multa)> RelatorioEmprestimos()
        {
            var relatorio = relatorios.GerarRelatorioEmprestimos();
            return relatorio;
        }

        public List<(string Nome, string Telefone, string Cpf, string Email, int TotalEmprestimos)> RelatorioUsuarios()
        {
            var relatorio = relatorios.GerarRelatorioUsuarios();
            return relatorio;
        }

        public List<(string Titulo, string Isbn, int Quantidade,string genero, string LinkCapa)> ObterLivrosParaExibicao()
        {
            var livros = bibliotecario.ObterLivrosParaExibicao();
            return livros;
        }

        public async Task<bool> VerificarLinkImagemAsync(string url)
        {
            Verificador verificador = new Verificador();
            var retorno = await verificador.VerificarLinkImagemAsync(url);
            return retorno;
        }

        // Exemplo de consulta geral
        public List<Livro> ListarLivros()
        {
            return new CarregarDados().CarregarLivros();
        }
    }
}
