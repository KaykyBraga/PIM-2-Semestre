﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Senha { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Cpf { get; set; }

        public static string EmailLogado { get; set; } // Propriedade estática para armazenar o email do usuário logado

        internal Bibliotecario Bibliotecario
        {
            get => default;
            set
            {
            }
        }

        internal LoginCadastro LoginCadastro
        {
            get => default;
            set
            {
            }
        }

        // Construtor padrão
        public Usuario() { }       
    }

}
