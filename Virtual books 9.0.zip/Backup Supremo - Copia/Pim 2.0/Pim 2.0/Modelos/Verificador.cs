﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Verificador
    {
        public Verificador() { }

        internal Bibliotecario Bibliotecario
        {
            get => default;
            set
            {
            }
        }

        internal LoginCadastro LoginCadastro
        {
            get => default;
            set
            {
            }
        }

        public bool VerificarEmail(string email, List<Usuario> usuarios, out string mensagemErro)
        {
            mensagemErro = "";

            string padraoEmail = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
            if (!Regex.IsMatch(email, padraoEmail, RegexOptions.IgnoreCase))
            {
                mensagemErro = "Formato de e-mail inválido.";
                return false;
            }

            if (usuarios.Any(u => u.Email == email))
            {
                mensagemErro = "Este e-mail já está cadastrado.";
                return false;
            }

            return true; // Válido e não cadastrado
        }

        public bool VerificarCpf(string cpf, List<Usuario> usuarios, out string mensagemErro)
        {
            mensagemErro = "";

            cpf = new string(cpf.Where(char.IsDigit).ToArray());

            if (cpf.Length != 11)
            {
                mensagemErro = "O CPF deve conter 11 dígitos.";
                return false;
            }

            if (cpf.Distinct().Count() == 1)
            {
                mensagemErro = "CPF inválido. Todos os dígitos são iguais.";
                return false;
            }

            int soma = 0;
            for (int i = 0; i < 9; i++)
                soma += (cpf[i] - '0') * (10 - i);

            int primeiroDigito = soma % 11;
            primeiroDigito = (primeiroDigito < 2) ? 0 : 11 - primeiroDigito;

            if ((cpf[9] - '0') != primeiroDigito)
            {
                mensagemErro = "CPF inválido.";
                return false;
            }

            soma = 0;
            for (int i = 0; i < 10; i++)
                soma += (cpf[i] - '0') * (11 - i);

            int segundoDigito = soma % 11;
            segundoDigito = (segundoDigito < 2) ? 0 : 11 - segundoDigito;

            if ((cpf[10] - '0') != segundoDigito)
            {
                mensagemErro = "CPF inválido.";
                return false;
            }

            if (usuarios.Any(u => u.Cpf == cpf))
            {
                mensagemErro = "Este CPF já está cadastrado.";
                return false;
            }

            return true; // Válido e não cadastrado
        }

        public bool VerificarLivroExistente(string isbn, List<Livro> livros, out int indiceLivro)
        {
            for (int i = 0; i < livros.Count; i++)
            {
                if (livros[i].Isbn == isbn)
                {
                    indiceLivro = i;
                    return true; // Livro já cadastrado
                }
            }

            indiceLivro = -1; // Livro não encontrado
            return false; // Livro válido e ainda não cadastrado
        }
        public async Task<bool> VerificarLinkImagemAsync(string url)
        {
            if (!Uri.TryCreate(url, UriKind.Absolute, out Uri uriResult) ||
                (uriResult.Scheme != Uri.UriSchemeHttp && uriResult.Scheme != Uri.UriSchemeHttps))
            {
                return false;
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var request = new HttpRequestMessage(HttpMethod.Head, uriResult);
                    var response = await client.SendAsync(request);
                    return response.IsSuccessStatusCode &&
                           response.Content.Headers.ContentType.MediaType.StartsWith("image/");
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
