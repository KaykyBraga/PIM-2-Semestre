﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    public class Livro
    {
        public int Id { get; set; }
        public string Isbn { get; set; }
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Editora { get; set; }
        public string Ano { get; set; }
        public string Genero { get; set; }
        public int Quantidade { get; set; }
        public int QuantidadeVezesEmprestado { get; set; }
        public string LinkCapa { get; set; }

        internal Bibliotecario Bibliotecario
        {
            get => default;
            set
            {
            }
        }
    }
}
