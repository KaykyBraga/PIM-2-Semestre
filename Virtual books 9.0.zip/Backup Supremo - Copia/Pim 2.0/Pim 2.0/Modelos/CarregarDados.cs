﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class CarregarDados
    {
        private readonly string caminho = "usuarios.txt";

        internal ControleBibliotecario ControleBibliotecario
        {
            get => default;
            set
            {
            }
        }

        internal ControleUsuario ControleUsuario
        {
            get => default;
            set
            {
            }
        }

        public List<Usuario> CarregarUsuarios()
        {
            List<Usuario> usuarios = new List<Usuario>();

            if (!File.Exists(caminho))
            {
                File.Create(caminho).Close(); // Cria o arquivo vazio se não existir
                return usuarios;
            }

            string[] linhas = File.ReadAllLines(caminho);
            foreach (var linha in linhas)
            {
                string[] dados = linha.Split(',');
                if (dados.Length >= 6)
                {
                    Usuario usuario = new Usuario
                    {
                        Id = int.Parse(dados[0]),
                        Nome = dados[1],
                        Senha = dados[2],
                        Email = dados[3],
                        Telefone = dados[4],
                        Cpf = dados[5]
                    };
                    usuarios.Add(usuario);
                }
            }

            return usuarios;
        }

        public List<Livro> CarregarLivros()
        {
            string caminho = "livros.txt";
            var livros = new List<Livro>();

            if (!File.Exists(caminho))
            {
                File.Create(caminho).Close();
                return livros; // retorna lista vazia
            }

            string[] linhas = File.ReadAllLines(caminho);

            foreach (var linha in linhas)
            {
                string[] dados = linha.Split(';');
                if (dados.Length < 10)
                    continue; // pula linhas inválidas

                Livro livro = new Livro
                {
                    Id = int.Parse(dados[0]),
                    Isbn = dados[1],
                    Titulo = dados[2],
                    Autor = dados[3],
                    Editora = dados[4],
                    Ano = dados[5],
                    Genero = dados[6],
                    Quantidade = int.Parse(dados[7]),
                    QuantidadeVezesEmprestado = int.Parse(dados[8]),
                    LinkCapa = dados[9]
                };

                livros.Add(livro);
            }

            return livros;
        }


        public List<Emprestimos> CarregarEmprestimos()
        {
            string caminho = "emprestimos.txt";
            var emprestimos = new List<Emprestimos>();
            DateTime hoje = DateTime.Today;

            if (!File.Exists(caminho))
            {
                File.Create(caminho).Close();
                return emprestimos; // lista vazia
            }

            string[] linhas = File.ReadAllLines(caminho);

            foreach (var linha in linhas)
            {
                string[] dados = linha.Split(',');
                if (dados.Length < 7)
                    continue; // pula linhas inválidas

                Emprestimos e = new Emprestimos
                {
                    Id = int.Parse(dados[0]),
                    CpfUsuario = dados[1],
                    IsbnLivro = dados[2],
                    DataEmprestimo = DateTime.Parse(dados[3]),
                    DataDevolucaoPrevista = DateTime.Parse(dados[4]),
                    DataDevolucaoReal = string.IsNullOrWhiteSpace(dados[5]) ? (DateTime?)null : DateTime.Parse(dados[5]),
                    Status = int.Parse(dados[6])
                };

                // Atualiza status para atrasado se necessário
                if (e.DataDevolucaoPrevista < hoje && e.Status == 0)
                {
                    e.Status = 2; // atrasado
                }
                
                emprestimos.Add(e);                
            }
            SalvarDados salvarDados = new SalvarDados();
            salvarDados.SalvarEmprestimos(emprestimos);

            return emprestimos;
        }

    }
}
