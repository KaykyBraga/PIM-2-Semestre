﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Bibliotecario
    {
        private static string email = "admin";
        public static string Email => email;

        private static string senha = "admin";
        public static string Senha => senha;

        private List<Livro> livros;
        private List<Usuario> usuarios;
        private List<Emprestimos> emprestimos;

        public Bibliotecario(List<Livro> livrosExistentes, List<Usuario> usuariosExistentes, List<Emprestimos> emprestimosExistentes)
        {
            livros = livrosExistentes;
            usuarios = usuariosExistentes;
            emprestimos = emprestimosExistentes;
        }

        public void AddLivro(string isbn, string titulo, string autor, string editora, string ano, string genero, string qtdlivro, string capa, out int erro)
        {
            Verificador verificador = new Verificador();

            if (verificador.VerificarLivroExistente(isbn, livros, out _))
            {
                erro = 1; // livro já existe
                return;
            }

            if (!int.TryParse(qtdlivro, out int quantidade))
            {
                erro = 2; // erro na conversão
                return;
            }

            var novoLivro = new Livro
            {
                Id = livros.Count + 1,
                Isbn = isbn,
                Titulo = titulo,
                Autor = autor,
                Editora = editora,
                Ano = ano,
                Genero = genero,
                Quantidade = quantidade,
                LinkCapa = capa,
                QuantidadeVezesEmprestado = 0
            };

            livros.Add(novoLivro);

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarLivros(livros);

            erro = 0; // sucesso
        }

        public async Task<(bool encontrado, string titulo, string autor, string editora, string ano, string genero, string capaUrl, string mensagem)> BuscarLivroPorIsbnAsync(string isbn)
        {
            Verificador verificador = new Verificador();

            if (verificador.VerificarLivroExistente(isbn, livros, out _))
                return (false, "", "", "", "", "", "", "Livro já cadastrado!");

            using var http = new HttpClient();
            string url = $"https://www.googleapis.com/books/v1/volumes?q=isbn:{isbn}";

            var resposta = await http.GetAsync(url);
            if (!resposta.IsSuccessStatusCode)
                return (false, "", "", "", "", "", "", "");

            using var jsonDoc = JsonDocument.Parse(await resposta.Content.ReadAsStringAsync());

            if (!jsonDoc.RootElement.TryGetProperty("items", out var items))
                return (false, "", "", "", "", "", "", "");

            var volume = items[0].GetProperty("volumeInfo");

            string titulo = volume.TryGetProperty("title", out var t) ? t.GetString() ?? "Desconhecido" : "Desconhecido";
            string autor = volume.TryGetProperty("authors", out var a) && a.GetArrayLength() > 0 ? a[0].GetString() ?? "Desconhecido" : "Desconhecido";
            string editora = volume.TryGetProperty("publisher", out var e) ? e.GetString() ?? "Desconhecida" : "Desconhecida";
            string ano = volume.TryGetProperty("publishedDate", out var d) ? d.GetString() ?? "Desconhecido" : "Desconhecido";
            string genero = volume.TryGetProperty("categories", out var g) ? string.Join(", ", g.EnumerateArray().Select(x => x.GetString())) : "Indefinido";
            string capaUrl = volume.TryGetProperty("imageLinks", out var img) && img.TryGetProperty("thumbnail", out var capa) ? capa.GetString() ?? "" : "";

            return (true, titulo, autor, editora, ano, genero, capaUrl, "");
        }

        public void AumentarLivros(string isbn, string qtdlivro, out int erro)
        {
            if (!int.TryParse(qtdlivro, out int quantidade))
            {
                erro = 1; // erro na conversão
                return;
            }

            var livro = livros.FirstOrDefault(l => l.Isbn == isbn);
            if (livro == null)
            {
                erro = 2; // livro não encontrado
                return;
            }

            livro.Quantidade += quantidade;

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarLivros(livros);

            erro = 0; // sucesso
        }

        public void RemoverLivro(string isbn, string qtdlivro, out int erro)
        {
            if (!int.TryParse(qtdlivro, out int quantidade))
            {
                erro = 1;
                return;
            }

            var livro = livros.FirstOrDefault(l => l.Isbn == isbn);
            if (livro == null)
            {
                erro = 3; // livro não encontrado
                return;
            }

            if (quantidade > livro.Quantidade)
            {
                erro = 2; // quantidade maior que disponível
                return;
            }

            livro.Quantidade -= quantidade;

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarLivros(livros);

            erro = 0; // sucesso
        }

        public void EmprestarLivro(string isbn, string cpf, out int erro)
        {
            var usuario = usuarios.FirstOrDefault(u => u.Cpf == cpf);
            if (usuario == null)
            {
                erro = 1; // usuário não encontrado
                return;
            }

            int livrosEmprestadosAtivos = emprestimos.Count(e => e.CpfUsuario == cpf && e.Status == 0);
            if (livrosEmprestadosAtivos >= 3)
            {
                erro = 2; // limite de empréstimos atingido
                return;
            }

            var livro = livros.FirstOrDefault(l => l.Isbn == isbn && l.Quantidade > 0);
            if (livro == null)
            {
                erro = 3; // livro não encontrado ou indisponível
                return;
            }

            livro.Quantidade--;
            livro.QuantidadeVezesEmprestado++;

            var novoEmprestimo = new Emprestimos
            {
                Id = emprestimos.Count + 1,
                CpfUsuario = cpf,
                IsbnLivro = isbn,
                DataEmprestimo = DateTime.Today,
                DataDevolucaoPrevista = DateTime.Today.AddDays(7),
                Status = 0 // ativo
            };

            emprestimos.Add(novoEmprestimo);

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarEmprestimos(emprestimos);
            salvar.SalvarLivros(livros);

            erro = 0; // sucesso
        }

        public void DevolverLivro(string isbn, string cpf, out int erro, out decimal multa)
        {
            var emprestimo = emprestimos.FirstOrDefault(e => e.CpfUsuario == cpf && e.IsbnLivro == isbn && (e.Status == 0 || e.Status == 2));
            if (emprestimo == null)
            {
                erro = 1; // empréstimo não encontrado
                multa = 0;
                return;
            }

            DateTime dataDevolucaoReal = DateTime.Today;
            emprestimo.DataDevolucaoReal = dataDevolucaoReal;
            emprestimo.Status = 1; // devolvido

            var livro = livros.FirstOrDefault(l => l.Isbn == isbn);
            if (livro != null)
                livro.Quantidade++;

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarEmprestimos(emprestimos);
            salvar.SalvarLivros(livros);

            Emprestimos emprestimoHelper = new Emprestimos();
            multa = emprestimoHelper.CalcularMulta(dataDevolucaoReal, emprestimo.DataDevolucaoPrevista);

            erro = multa > 0 ? 2 : 0; // 2 = devolvido com multa, 0 = devolvido sem multa
        }

        

        public List<(string Titulo, string Isbn, int Quantidade,string genero, string LinkCapa)> ObterLivrosParaExibicao()
        {
            return livros.Select(l => (
                l.Titulo,
                l.Isbn,
                l.Quantidade,
                l.Genero,
                string.IsNullOrEmpty(l.LinkCapa) ? "" : l.LinkCapa               
            )).ToList();
        }

        internal ControleBibliotecario ControleBibliotecario
        {
            get => default;
            set
            {
            }
        }
    }

}
