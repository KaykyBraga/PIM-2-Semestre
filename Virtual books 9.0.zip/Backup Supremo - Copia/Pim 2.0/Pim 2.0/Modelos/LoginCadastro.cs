﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class LoginCadastro
    {
        private List<Usuario> usuarios;

        public LoginCadastro(List<Usuario> usuariosExistentes)
        {
            usuarios = usuariosExistentes;
        }

        internal ControleUsuario ControleUsuario
        {
            get => default;
            set
            {
            }
        }

        public bool CriarContaUsuario(string nome, string senha, string email, string telefone, string cpf, out string mensagemErro)
        {
            Verificador verificar = new Verificador();

            if (!verificar.VerificarEmail(email, usuarios, out mensagemErro))
                return false;

            if (!verificar.VerificarCpf(cpf, usuarios, out mensagemErro))
                return false;

            Usuario novoUsuario = new Usuario
            {
                Id = usuarios.Count + 1,
                Nome = nome,
                Senha = senha,
                Email = email,
                Telefone = telefone,
                Cpf = cpf
            };

            usuarios.Add(novoUsuario);

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarUsuarios(usuarios);

            mensagemErro = "Cadastro concluído com sucesso!";
            return true;
        }

        public bool LoginBibliotecario(string email, string senha)
        {
            return (Bibliotecario.Email == email && Bibliotecario.Senha == senha);
        }

        public int LoginUsuario(string cpfOuEmail, string senha)
        {
            if (usuarios.Any(u => (u.Email == cpfOuEmail || u.Cpf == cpfOuEmail) && u.Senha == senha))
            {
                // Tela de usuário comum
                return 1;
            }

            if (LoginBibliotecario(cpfOuEmail, senha))
            {
                // Tela de bibliotecário
                return 2;
            }

            // Login inválido
            return 3;
        }

        public int RedefinirSenha(string cpf, string email, string telefone, string senha, string confirmacaoSenha)
        {
            var usuario = usuarios.FirstOrDefault(u => u.Cpf == cpf && u.Email == email && u.Telefone == telefone);
            if (usuario == null)
                return 2; // Dados incorretos

            if (senha != confirmacaoSenha)
                return 1; // Senhas não coincidem

            usuario.Senha = senha;

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarUsuarios(usuarios);

            return 0; // Sucesso
        }
    }


}
