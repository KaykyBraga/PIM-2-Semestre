﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class ControleUsuario
    {
       
        private LoginCadastro loginCadastro;
        private Relatorios relatorios;
        private Bibliotecario bibliotecario;
        public ControleUsuario()
        {
            CarregarDados carregar = new CarregarDados();
            var usuarios = carregar.CarregarUsuarios();
            var livros = carregar.CarregarLivros();
            var emprestimos = carregar.CarregarEmprestimos();
            loginCadastro = new LoginCadastro(usuarios);
            relatorios = new Relatorios(livros, usuarios, emprestimos);
            bibliotecario = new Bibliotecario(livros, usuarios, emprestimos);
        }
     

        // Exemplo do método para salvar usuários (você já deve ter no SalvarDados)
        

        // Método para criar conta, chamando LoginCadastro
        public bool CriarConta(string nome, string senha, string email, string telefone, string cpf, out string mensagemErro)
        {
            var sucesso = loginCadastro.CriarContaUsuario(nome, senha, email, telefone, cpf, out mensagemErro);
            
            return sucesso;
        }

        // Método para login, retorna o int conforme seu método LoginUsuario
        public int Login(string cpfOuEmail, string senha)
        {
            return loginCadastro.LoginUsuario(cpfOuEmail, senha);
        }

        // Método para redefinir senha
        public int RedefinirSenha(string cpf, string email, string telefone, string novaSenha, string confirmacaoSenha)
        {
            var resultado = loginCadastro.RedefinirSenha(cpf, email, telefone, novaSenha, confirmacaoSenha);
            
            return resultado;
        }

        public List<(string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoPrevista, string DataDevolucaoReal, string Status, string Multa)> HistoricoUsuario(string email)
        {
            var historico = relatorios.ObterHistoricoEmprestimosUsuario(email);
            return historico;
        }

        public List<(string Titulo, string Isbn, int Quantidade, string genero, string LinkCapa)> ObterLivrosParaExibicao()
        {
            var livros = bibliotecario.ObterLivrosParaExibicao();
            return livros;
        }

    }
}
