﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Emprestimos
    {
        public int Id { get; set; }
        public string CpfUsuario { get; set; }
        public string IsbnLivro { get; set; }
        public DateTime DataEmprestimo { get; set; }
        public DateTime DataDevolucaoPrevista { get; set; }
        public DateTime? DataDevolucaoReal { get; set; }
        public int Status { get; set; } // 0 - ativo, 1 - devolvido, 2 - atrasado

        internal Bibliotecario Bibliotecario
        {
            get => default;
            set
            {
            }
        }

        public Emprestimos() { }

        

        public decimal CalcularMulta(DateTime dataDevolucaoReal, DateTime dataDevolucaoPresvista, decimal multaPorDia = 0.50m)
        {
            if (dataDevolucaoReal > dataDevolucaoPresvista)
            {
                TimeSpan diasAtraso = dataDevolucaoReal.Date - dataDevolucaoPresvista.Date;
                return (decimal)diasAtraso.Days * multaPorDia;
            }
            else
            {
                return 0m;
            }
        }
    }
}
