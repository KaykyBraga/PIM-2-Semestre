﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class SalvarDados
    {
        private readonly string caminho = "usuarios.txt";

        internal Bibliotecario Bibliotecario
        {
            get => default;
            set
            {
            }
        }

        internal LoginCadastro LoginCadastro
        {
            get => default;
            set
            {
            }
        }

        public void SalvarUsuarios(List<Usuario> usuarios)
        {
            List<string> linhas = new List<string>();

            foreach (var usuario in usuarios)
            {
                linhas.Add($"{usuario.Id},{usuario.Nome},{usuario.Senha},{usuario.Email},{usuario.Telefone},{usuario.Cpf}");
            }

            File.WriteAllLines(caminho, linhas);
        }

        public void SalvarLivros(List<Livro> livros)
        {
            string[] linhas = new string[livros.Count];
            for (int i = 0; i < livros.Count; i++)
            {
                var livro = livros[i];
                linhas[i] = $"{livro.Id};{livro.Isbn};{livro.Titulo};" +
                    $"{livro.Autor};{livro.Editora};{livro.Ano};{livro.Genero};" +
                    $"{livro.Quantidade};{livro.QuantidadeVezesEmprestado};{livro.LinkCapa}";
            }
            File.WriteAllLines("livros.txt", linhas);
        }

        public void SalvarEmprestimos(List<Emprestimos> emprestimos)
        {
            string[] linhas = new string[emprestimos.Count];

            for (int i = 0; i < emprestimos.Count; i++)
            {
                var e = emprestimos[i];
                // Se data real for null, salvar vazio
                string dataDevolucaoReal = e.DataDevolucaoReal.HasValue ? e.DataDevolucaoReal.Value.ToString("yyyy-MM-dd") : "";

                linhas[i] = $"{e.Id},{e.CpfUsuario},{e.IsbnLivro},{e.DataEmprestimo:yyyy-MM-dd}," +
                            $"{e.DataDevolucaoPrevista:yyyy-MM-dd},{dataDevolucaoReal},{e.Status}";
            }

            File.WriteAllLines("emprestimos.txt", linhas);
        }

    }
}
