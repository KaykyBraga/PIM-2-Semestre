﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Relatorios
    {
        private List<Livro> livros;
        private List<Usuario> usuarios;
        private List<Emprestimos> emprestimos;

        public Relatorios(List<Livro> livrosExistentes, List<Usuario> usuariosExistentes, List<Emprestimos> emprestimosExistentes)
        {
            livros = livrosExistentes;
            usuarios = usuariosExistentes;
            emprestimos = emprestimosExistentes;
        }

        internal ControleUsuario ControleUsuario
        {
            get => default;
            set
            {
            }
        }

        internal ControleBibliotecario ControleBibliotecario
        {
            get => default;
            set
            {
            }
        }

        public List<(string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoPrevista, string DataDevolucaoReal, string Status, string Multa)> ObterHistoricoEmprestimosUsuario(string emailUsuario)
        {
            var historico = new List<(string, string, string, string, string, string, string)>();

            // Procura o usuário na lista interna `usuarios`
            var usuario = usuarios.FirstOrDefault(u => u.Email == emailUsuario);
            if (usuario == null)
                return historico; // usuário não encontrado: retorna lista vazia

            Emprestimos helper = new Emprestimos();

            // Filtra os empréstimos da lista interna `emprestimos` do usuário encontrado
            var emprestimosUsuario = emprestimos.Where(e => e.CpfUsuario == usuario.Cpf);

            foreach (var emp in emprestimosUsuario.OrderByDescending(e => e.Id))
            {
                // Busca o livro na lista interna `livros` pelo ISBN do empréstimo
                var livro = livros.FirstOrDefault(l => l.Isbn == emp.IsbnLivro);
                if (livro == null)
                    continue; // pula caso o livro não esteja cadastrado

                string statusTexto = emp.Status switch
                {
                    0 => "Ativo",
                    1 => "Devolvido",
                    2 => "Atrasado",
                    _ => "Desconhecido"
                };

                string dataDevolucaoReal = emp.DataDevolucaoReal.HasValue
                    ? emp.DataDevolucaoReal.Value.ToString("dd/MM/yyyy")
                    : "Não devolvido";

                decimal multaValor = helper.CalcularMulta(
                    emp.DataDevolucaoReal.GetValueOrDefault(DateTime.Today),
                    emp.DataDevolucaoPrevista
                );


                historico.Add((
                    livro.Titulo,
                    livro.Isbn,
                    emp.DataEmprestimo.ToString("dd/MM/yyyy"),
                    emp.DataDevolucaoPrevista.ToString("dd/MM/yyyy"),
                    dataDevolucaoReal,
                    statusTexto,
                    multaValor > 0 ? multaValor.ToString("C2") : "Sem multa"
                ));
            }

            return historico;
        }

        public List<(string titulo, string autor, string genero, int quantidade, string isbn, string disponibilidade)> GerarRelatorioEstoque()
        {
            var relatorio = new List<(string, string, string, int, string, string)>();

            foreach (var livro in livros.OrderByDescending(l => l.Id))
            {
                string disponibilidade = livro.Quantidade > 0 ? "Disponível" : "Indisponível";
                relatorio.Add((livro.Titulo, livro.Autor, livro.Genero, livro.Quantidade, livro.Isbn, disponibilidade));
            }

            return relatorio;
        }

        public List<(string Nome, string Telefone, string Cpf, string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoPrevista, string Status, string Multa)> GerarRelatorioEmprestimosAtrasados()
        {
            var listaRelatorio = new List<(string, string, string, string, string, string, string, string, string)>();
            DateTime dataHoje = DateTime.Today;

            for (int i = 0; i < emprestimos.Count; i++)
            {
                var emp = emprestimos[i];
                if (emp.Status == 2) // atrasado
                {
                    // Buscar usuário
                    var usuario = usuarios.FirstOrDefault(u => u.Cpf == emp.CpfUsuario);
                    string nome = usuario != null ? usuario.Nome : "";
                    string telefone = usuario != null ? usuario.Telefone : "";

                    // Buscar livro
                    var livro = livros.FirstOrDefault(l => l.Isbn == emp.IsbnLivro);
                    string titulo = livro != null ? livro.Titulo : "";

                    // Calcular multa
                    decimal multa = emp.CalcularMulta(dataHoje, emp.DataDevolucaoPrevista);

                    string statusTexto = "Atrasado";
                    string multaTexto = multa == 0 ? "Sem multa" : multa.ToString("C2");

                    listaRelatorio.Add((
                        nome,
                        telefone,
                        emp.CpfUsuario,
                        titulo,
                        emp.IsbnLivro,
                        emp.DataEmprestimo.ToString("dd/MM/yyyy"),
                        emp.DataDevolucaoPrevista.ToString("dd/MM/yyyy"),
                        statusTexto,
                        multaTexto
                    ));
                }
            }

            return listaRelatorio;
        }

        public List<(string Ranking, string Titulo, string Autor, string Genero, string Isbn, int QtdEmprestimos)> GerarRelatorioLivrosMaisEmprestados()
        {
            var livrosOrdenados = livros
                .OrderByDescending(l => l.QuantidadeVezesEmprestado)
                .Select((livro, index) => (
                    Ranking: $"{index + 1}°",
                    livro.Titulo,
                    livro.Autor,
                    livro.Genero,
                    livro.Isbn,
                    livro.QuantidadeVezesEmprestado
                )).ToList();

            return livrosOrdenados;
        }

        public List<(string Nome, string Telefone, string Cpf, string Titulo, string Isbn, string DataEmprestimo, string DataDevolucaoReal, string DataDevolucaoPrevista, string Status, string Multa)> GerarRelatorioEmprestimos()
        {
            var relatorio = new List<(string, string, string, string, string, string, string, string, string, string)>();
            Emprestimos helper = new Emprestimos();

            foreach (var emprestimo in emprestimos
                .Where(e => e.Status == 0 || e.Status == 1)
                .OrderByDescending(e => e.Id))
            {
                var usuario = usuarios.FirstOrDefault(u => u.Cpf == emprestimo.CpfUsuario);
                var livro = livros.FirstOrDefault(l => l.Isbn == emprestimo.IsbnLivro);

                if (usuario == null || livro == null)
                    continue;

                string nome = usuario.Nome;
                string telefone = usuario.Telefone;
                string cpf = usuario.Cpf;
                string titulo = livro.Titulo;
                string isbn = livro.Isbn;

                string dataEmprestimo = emprestimo.DataEmprestimo.ToString("dd/MM/yyyy");
                string dataDevolucaoReal = emprestimo.DataDevolucaoReal != DateTime.MinValue
                    ? emprestimo.DataDevolucaoReal?.ToString("dd/MM/yyyy") ?? "Pendente"
                    : "Pendente";
                string dataDevolucaoPrevista = emprestimo.DataDevolucaoPrevista.ToString("dd/MM/yyyy");

                string status = emprestimo.Status switch
                {
                    0 => "Emprestado",
                    1 => "Devolvido",
                    _ => "Desconhecido"
                };

                decimal multaValor = helper.CalcularMulta(
                    emprestimo.DataDevolucaoReal ?? DateTime.Today,
                    emprestimo.DataDevolucaoPrevista
                );

                string multa = multaValor > 0 ? multaValor.ToString("C2") : "Sem multa";

                relatorio.Add((nome, telefone, cpf, titulo, isbn, dataEmprestimo, dataDevolucaoReal, dataDevolucaoPrevista, status, multa));
            }

            return relatorio;
        }


        public List<(string Nome, string Telefone, string Cpf, string Email, int TotalEmprestimos)> GerarRelatorioUsuarios()
        {
            var relatorio = new List<(string, string, string, string, int)>();

            foreach (var usuario in usuarios)
            {
                int totalEmprestimos = emprestimos.Count(e => e.CpfUsuario == usuario.Cpf);

                relatorio.Add((usuario.Nome, usuario.Telefone, usuario.Cpf, usuario.Email, totalEmprestimos));
            }

            return relatorio;
        }
    }
}
