﻿namespace Pim_2._0.TelasAdm
{
    partial class RelatorioEmprestimos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RelatorioEmprestimos));
            txtpesquisa = new TextBox();
            dgvEmprestimos = new DataGridView();
            nome = new DataGridViewTextBoxColumn();
            Telefone = new DataGridViewTextBoxColumn();
            Cpf = new DataGridViewTextBoxColumn();
            Titulo = new DataGridViewTextBoxColumn();
            ISBN = new DataGridViewTextBoxColumn();
            DataEmprestimo = new DataGridViewTextBoxColumn();
            DataEntrega = new DataGridViewTextBoxColumn();
            DataPrevista = new DataGridViewTextBoxColumn();
            StatusEmprestimo = new DataGridViewTextBoxColumn();
            Multa = new DataGridViewTextBoxColumn();
            timer1 = new System.Windows.Forms.Timer(components);
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimos).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // txtpesquisa
            // 
            txtpesquisa.Location = new Point(0, 134);
            txtpesquisa.Name = "txtpesquisa";
            txtpesquisa.Size = new Size(182, 23);
            txtpesquisa.TabIndex = 0;
            txtpesquisa.TextChanged += txtpesquisa_TextChanged;
            // 
            // dgvEmprestimos
            // 
            dgvEmprestimos.AllowUserToAddRows = false;
            dgvEmprestimos.AllowUserToDeleteRows = false;
            dgvEmprestimos.AllowUserToResizeColumns = false;
            dgvEmprestimos.AllowUserToResizeRows = false;
            dgvEmprestimos.BackgroundColor = Color.LightGray;
            dgvEmprestimos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEmprestimos.Columns.AddRange(new DataGridViewColumn[] { nome, Telefone, Cpf, Titulo, ISBN, DataEmprestimo, DataEntrega, DataPrevista, StatusEmprestimo, Multa });
            dgvEmprestimos.Dock = DockStyle.Bottom;
            dgvEmprestimos.Location = new Point(0, 159);
            dgvEmprestimos.Name = "dgvEmprestimos";
            dgvEmprestimos.ReadOnly = true;
            dgvEmprestimos.Size = new Size(1085, 476);
            dgvEmprestimos.TabIndex = 1;
            // 
            // nome
            // 
            nome.HeaderText = "Nome";
            nome.Name = "nome";
            nome.ReadOnly = true;
            nome.Width = 180;
            // 
            // Telefone
            // 
            Telefone.HeaderText = "Telefone";
            Telefone.Name = "Telefone";
            Telefone.ReadOnly = true;
            Telefone.Width = 90;
            // 
            // Cpf
            // 
            Cpf.HeaderText = "Cpf";
            Cpf.Name = "Cpf";
            Cpf.ReadOnly = true;
            Cpf.Width = 85;
            // 
            // Titulo
            // 
            Titulo.HeaderText = "Título";
            Titulo.Name = "Titulo";
            Titulo.ReadOnly = true;
            Titulo.Width = 180;
            // 
            // ISBN
            // 
            ISBN.HeaderText = "ISBN";
            ISBN.Name = "ISBN";
            ISBN.ReadOnly = true;
            ISBN.Width = 90;
            // 
            // DataEmprestimo
            // 
            DataEmprestimo.HeaderText = "Data Emprestimo";
            DataEmprestimo.Name = "DataEmprestimo";
            DataEmprestimo.ReadOnly = true;
            DataEmprestimo.Width = 75;
            // 
            // DataEntrega
            // 
            DataEntrega.HeaderText = "Data Entrega";
            DataEntrega.Name = "DataEntrega";
            DataEntrega.ReadOnly = true;
            DataEntrega.Width = 75;
            // 
            // DataPrevista
            // 
            DataPrevista.HeaderText = "Data Prevista";
            DataPrevista.Name = "DataPrevista";
            DataPrevista.ReadOnly = true;
            DataPrevista.Width = 75;
            // 
            // StatusEmprestimo
            // 
            StatusEmprestimo.HeaderText = "Status Emprestimo";
            StatusEmprestimo.Name = "StatusEmprestimo";
            StatusEmprestimo.ReadOnly = true;
            StatusEmprestimo.Width = 75;
            // 
            // Multa
            // 
            Multa.HeaderText = "Multa";
            Multa.Name = "Multa";
            Multa.ReadOnly = true;
            // 
            // timer1
            // 
            timer1.Interval = 300;
            timer1.Tick += timer1_Tick;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 42;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(471, 101);
            label2.Name = "label2";
            label2.Size = new Size(139, 30);
            label2.TabIndex = 53;
            label2.Text = "Empréstimos";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 52;
            label1.Text = "VirtualBooks";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 54;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(457, 38);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // RelatorioEmprestimos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvEmprestimos);
            Controls.Add(txtpesquisa);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "RelatorioEmprestimos";
            Text = "RelatorioEmprestimos";
            Load += RelatorioEmprestimos_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEmprestimos).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtpesquisa;
        private DataGridView dgvEmprestimos;
        private System.Windows.Forms.Timer timer1;
        private DataGridViewTextBoxColumn nome;
        private DataGridViewTextBoxColumn Telefone;
        private DataGridViewTextBoxColumn Cpf;
        private DataGridViewTextBoxColumn Titulo;
        private DataGridViewTextBoxColumn ISBN;
        private DataGridViewTextBoxColumn DataEmprestimo;
        private DataGridViewTextBoxColumn DataEntrega;
        private DataGridViewTextBoxColumn DataPrevista;
        private DataGridViewTextBoxColumn StatusEmprestimo;
        private DataGridViewTextBoxColumn Multa;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label label12;
    }
}