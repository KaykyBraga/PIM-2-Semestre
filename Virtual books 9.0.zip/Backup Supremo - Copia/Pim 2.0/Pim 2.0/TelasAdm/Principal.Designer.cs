﻿namespace Pim_2._0.TelasAdm
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            label1 = new Label();
            btnAddLivro = new Button();
            btnRemoverLivro = new Button();
            btnEmprestarLivro = new Button();
            BtnDevolverLivro = new Button();
            label2 = new Label();
            button1 = new Button();
            button2 = new Button();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            btnSair = new Button();
            lblVirtualBooks = new Label();
            btnRelatorioEmpAtrasados = new Button();
            btnRelatorioEmprestimo = new Button();
            btnRelatorioLivrosMaisEmprestados = new Button();
            btnRelatorioUsuarios = new Button();
            btnRelatorioEstoque = new Button();
            label3 = new Label();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            button3 = new Button();
            panel2 = new Panel();
            panel3 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 11;
            label1.Text = "VirtualBooks";
            // 
            // btnAddLivro
            // 
            btnAddLivro.BackColor = SystemColors.ButtonHighlight;
            btnAddLivro.Cursor = Cursors.Hand;
            btnAddLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddLivro.Location = new Point(261, 129);
            btnAddLivro.Name = "btnAddLivro";
            btnAddLivro.Size = new Size(222, 54);
            btnAddLivro.TabIndex = 12;
            btnAddLivro.Text = "Adicionar Novo Livro";
            btnAddLivro.UseVisualStyleBackColor = false;
            btnAddLivro.Click += btnAddLivro_Click;
            // 
            // btnRemoverLivro
            // 
            btnRemoverLivro.BackColor = SystemColors.ButtonHighlight;
            btnRemoverLivro.Cursor = Cursors.Hand;
            btnRemoverLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRemoverLivro.Location = new Point(261, 203);
            btnRemoverLivro.Name = "btnRemoverLivro";
            btnRemoverLivro.Size = new Size(222, 54);
            btnRemoverLivro.TabIndex = 13;
            btnRemoverLivro.Text = "Remover Livro";
            btnRemoverLivro.UseVisualStyleBackColor = false;
            btnRemoverLivro.Click += btnRemoverLivro_Click;
            // 
            // btnEmprestarLivro
            // 
            btnEmprestarLivro.BackColor = SystemColors.ButtonHighlight;
            btnEmprestarLivro.Cursor = Cursors.Hand;
            btnEmprestarLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEmprestarLivro.Location = new Point(17, 201);
            btnEmprestarLivro.Name = "btnEmprestarLivro";
            btnEmprestarLivro.Size = new Size(222, 54);
            btnEmprestarLivro.TabIndex = 14;
            btnEmprestarLivro.Text = "Emprestar Livro";
            btnEmprestarLivro.UseVisualStyleBackColor = false;
            btnEmprestarLivro.Click += btnEmprestarLivro_Click;
            // 
            // BtnDevolverLivro
            // 
            BtnDevolverLivro.BackColor = SystemColors.ButtonHighlight;
            BtnDevolverLivro.Cursor = Cursors.Hand;
            BtnDevolverLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDevolverLivro.Location = new Point(17, 272);
            BtnDevolverLivro.Name = "BtnDevolverLivro";
            BtnDevolverLivro.Size = new Size(222, 54);
            BtnDevolverLivro.TabIndex = 15;
            BtnDevolverLivro.Text = "Devolver Livro";
            BtnDevolverLivro.UseVisualStyleBackColor = false;
            BtnDevolverLivro.Click += BtnDevolverLivro_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(474, 103);
            label2.Name = "label2";
            label2.Size = new Size(137, 30);
            label2.TabIndex = 18;
            label2.Text = "Bibliotecário";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(261, 275);
            button1.Name = "button1";
            button1.Size = new Size(222, 54);
            button1.TabIndex = 19;
            button1.Text = "Aumentar Quantidade de Livros";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(927, 38);
            button2.Name = "button2";
            button2.Size = new Size(140, 35);
            button2.TabIndex = 24;
            button2.Text = "Sair da Conta";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 40;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(btnSair);
            panel1.Controls.Add(lblVirtualBooks);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 41;
            // 
            // btnSair
            // 
            btnSair.BackColor = SystemColors.ButtonHighlight;
            btnSair.Cursor = Cursors.Hand;
            btnSair.Location = new Point(912, 23);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(140, 35);
            btnSair.TabIndex = 41;
            btnSair.Text = "Sair da Conta";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += button3_Click;
            // 
            // lblVirtualBooks
            // 
            lblVirtualBooks.AutoSize = true;
            lblVirtualBooks.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblVirtualBooks.ForeColor = Color.Silver;
            lblVirtualBooks.Location = new Point(457, 38);
            lblVirtualBooks.Name = "lblVirtualBooks";
            lblVirtualBooks.Size = new Size(166, 37);
            lblVirtualBooks.TabIndex = 10;
            lblVirtualBooks.Text = "VirtualBooks";
            // 
            // btnRelatorioEmpAtrasados
            // 
            btnRelatorioEmpAtrasados.BackColor = SystemColors.ButtonHighlight;
            btnRelatorioEmpAtrasados.Cursor = Cursors.Hand;
            btnRelatorioEmpAtrasados.Font = new Font("Segoe UI", 11.25F);
            btnRelatorioEmpAtrasados.Location = new Point(256, 128);
            btnRelatorioEmpAtrasados.Name = "btnRelatorioEmpAtrasados";
            btnRelatorioEmpAtrasados.Size = new Size(222, 52);
            btnRelatorioEmpAtrasados.TabIndex = 42;
            btnRelatorioEmpAtrasados.Text = "Emprestimos Atrasados";
            btnRelatorioEmpAtrasados.UseVisualStyleBackColor = false;
            btnRelatorioEmpAtrasados.Click += button4_Click;
            // 
            // btnRelatorioEmprestimo
            // 
            btnRelatorioEmprestimo.BackColor = SystemColors.ButtonHighlight;
            btnRelatorioEmprestimo.Cursor = Cursors.Hand;
            btnRelatorioEmprestimo.Font = new Font("Segoe UI", 11.25F);
            btnRelatorioEmprestimo.Location = new Point(17, 128);
            btnRelatorioEmprestimo.Name = "btnRelatorioEmprestimo";
            btnRelatorioEmprestimo.Size = new Size(222, 52);
            btnRelatorioEmprestimo.TabIndex = 43;
            btnRelatorioEmprestimo.Text = "Emprestimos";
            btnRelatorioEmprestimo.UseVisualStyleBackColor = false;
            btnRelatorioEmprestimo.Click += button5_Click;
            // 
            // btnRelatorioLivrosMaisEmprestados
            // 
            btnRelatorioLivrosMaisEmprestados.BackColor = SystemColors.ButtonHighlight;
            btnRelatorioLivrosMaisEmprestados.Cursor = Cursors.Hand;
            btnRelatorioLivrosMaisEmprestados.Font = new Font("Segoe UI", 11.25F);
            btnRelatorioLivrosMaisEmprestados.Location = new Point(18, 202);
            btnRelatorioLivrosMaisEmprestados.Name = "btnRelatorioLivrosMaisEmprestados";
            btnRelatorioLivrosMaisEmprestados.Size = new Size(222, 52);
            btnRelatorioLivrosMaisEmprestados.TabIndex = 44;
            btnRelatorioLivrosMaisEmprestados.Text = "Livros Mais Emprestados";
            btnRelatorioLivrosMaisEmprestados.UseVisualStyleBackColor = false;
            btnRelatorioLivrosMaisEmprestados.Click += button6_Click;
            // 
            // btnRelatorioUsuarios
            // 
            btnRelatorioUsuarios.BackColor = SystemColors.ButtonHighlight;
            btnRelatorioUsuarios.Cursor = Cursors.Hand;
            btnRelatorioUsuarios.Font = new Font("Segoe UI", 11.25F);
            btnRelatorioUsuarios.Location = new Point(256, 202);
            btnRelatorioUsuarios.Name = "btnRelatorioUsuarios";
            btnRelatorioUsuarios.Size = new Size(222, 52);
            btnRelatorioUsuarios.TabIndex = 45;
            btnRelatorioUsuarios.Text = "Usuarios";
            btnRelatorioUsuarios.UseVisualStyleBackColor = false;
            btnRelatorioUsuarios.Click += button7_Click;
            // 
            // btnRelatorioEstoque
            // 
            btnRelatorioEstoque.BackColor = SystemColors.ButtonHighlight;
            btnRelatorioEstoque.Cursor = Cursors.Hand;
            btnRelatorioEstoque.Font = new Font("Segoe UI", 11.25F);
            btnRelatorioEstoque.Location = new Point(138, 272);
            btnRelatorioEstoque.Name = "btnRelatorioEstoque";
            btnRelatorioEstoque.Size = new Size(222, 52);
            btnRelatorioEstoque.TabIndex = 46;
            btnRelatorioEstoque.Text = "Estoque";
            btnRelatorioEstoque.UseVisualStyleBackColor = false;
            btnRelatorioEstoque.Click += button8_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Silver;
            label3.Location = new Point(197, 20);
            label3.Name = "label3";
            label3.Size = new Size(101, 25);
            label3.TabIndex = 47;
            label3.Text = "Relatórios";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Silver;
            label4.Location = new Point(168, 21);
            label4.Name = "label4";
            label4.Size = new Size(161, 25);
            label4.TabIndex = 48;
            label4.Text = "Gerenciar Livros ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(222, 51);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(50, 49);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 49;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(222, 52);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(54, 49);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 50;
            pictureBox3.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ButtonHighlight;
            button3.Cursor = Cursors.Hand;
            button3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(17, 129);
            button3.Name = "button3";
            button3.Size = new Size(222, 54);
            button3.TabIndex = 51;
            button3.Text = "Vizualizar Livros ";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.DarkSlateBlue;
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(btnRelatorioEstoque);
            panel2.Controls.Add(btnRelatorioUsuarios);
            panel2.Controls.Add(btnRelatorioLivrosMaisEmprestados);
            panel2.Controls.Add(btnRelatorioEmprestimo);
            panel2.Controls.Add(btnRelatorioEmpAtrasados);
            panel2.Location = new Point(35, 188);
            panel2.Name = "panel2";
            panel2.Size = new Size(492, 354);
            panel2.TabIndex = 52;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DarkSlateBlue;
            panel3.Controls.Add(button3);
            panel3.Controls.Add(pictureBox3);
            panel3.Controls.Add(label4);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(BtnDevolverLivro);
            panel3.Controls.Add(btnEmprestarLivro);
            panel3.Controls.Add(btnRemoverLivro);
            panel3.Controls.Add(btnAddLivro);
            panel3.Location = new Point(550, 188);
            panel3.Name = "panel3";
            panel3.Size = new Size(492, 354);
            panel3.TabIndex = 53;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(button2);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Principal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Principal";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnAddLivro;
        private Button btnRemoverLivro;
        private Button btnEmprestarLivro;
        private Button BtnDevolverLivro;
        private Label label2;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label lblVirtualBooks;
        private Button btnSair;
        private Button btnRelatorioEmpAtrasados;
        private Button btnRelatorioEmprestimo;
        private Button btnRelatorioLivrosMaisEmprestados;
        private Button btnRelatorioUsuarios;
        private Button btnRelatorioEstoque;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Button button3;
        private Panel panel2;
        private Panel panel3;
    }
}