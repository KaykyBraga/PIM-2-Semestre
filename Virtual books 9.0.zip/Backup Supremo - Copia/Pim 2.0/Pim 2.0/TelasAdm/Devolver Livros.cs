﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Devolver_Livros : Form
    {
        public Devolver_Livros()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            ControleBibliotecario bibliotecario = new ControleBibliotecario();
            if (!string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtCPF.Text))
            {
                var resultado = bibliotecario.RealizarDevolucao(txtIsbn.Text, txtCPF.Text, out string mensagem, out decimal multa);
                if (resultado)
                {
                    MessageBox.Show(mensagem, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtIsbn.Clear();
                    txtCPF.Clear();
                }
                else
                {
                    MessageBox.Show(mensagem, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
