﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class RelatorioEmprestimosAtrasados : Form
    {
        public RelatorioEmprestimosAtrasados()
        {
            InitializeComponent();
        }

        private void RelatorioEmprestimosAtrasados_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controle = new ControleBibliotecario();
            var relatorio = controle.RelatorioEmprestimosAtrasados();



            foreach (var livro in relatorio)
            {
                int rowIndex = dgvEmprestimos.Rows.Add(
                    livro.Nome,
                    livro.Telefone,
                    livro.Cpf,
                    livro.Titulo,
                    livro.Isbn,
                    livro.DataEmprestimo,
                    livro.DataDevolucaoPrevista,
                    livro.Status,
                    livro.Multa
                );

                // Pega a linha adicionada
                DataGridViewRow row = dgvEmprestimos.Rows[rowIndex];

                // Altera a cor da célula da coluna "Status Empréstimo" (índice 8)

                row.Cells[7].Style.BackColor = Color.Red;

                // Cor da multa
                if (livro.Multa != "Sem multa")
                {
                    if (decimal.TryParse(livro.Multa, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal multaDecimal))
                    {
                        if (multaDecimal > 0)
                            row.Cells[8].Style.BackColor = Color.LightYellow;
                    }
                }

            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }
    }
}
