﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class QuantidadeLivros : Form
    {
        public QuantidadeLivros()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            ControleBibliotecario bibliotecario = new ControleBibliotecario();

            if (!string.IsNullOrEmpty(txtIsbn.Text.Trim()) && !string.IsNullOrEmpty(txtQuantidade.Text.Trim()))
            {
                var resultado = bibliotecario.AumentarEstoque(txtIsbn.Text.Trim(), txtQuantidade.Text.Trim(), out string mensagem);
                if (resultado)
                {
                    MessageBox.Show(mensagem, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtIsbn.Clear();
                    txtQuantidade.Clear();
                }
                else
                {
                    MessageBox.Show(mensagem, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void QuantidadeLivros_Load(object sender, EventArgs e)
        {

        }
    }
}
