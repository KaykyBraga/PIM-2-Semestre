﻿namespace Pim_2._0.TelasAdm
{
    partial class RelatorioLivrosMaisEmprestados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RelatorioLivrosMaisEmprestados));
            dgvLivrosMais = new DataGridView();
            Ranking = new DataGridViewTextBoxColumn();
            Titulo = new DataGridViewTextBoxColumn();
            Autor = new DataGridViewTextBoxColumn();
            Genero = new DataGridViewTextBoxColumn();
            ISBN = new DataGridViewTextBoxColumn();
            QuantidadeDeEmprestimos = new DataGridViewTextBoxColumn();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvLivrosMais).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvLivrosMais
            // 
            dgvLivrosMais.AllowUserToAddRows = false;
            dgvLivrosMais.AllowUserToDeleteRows = false;
            dgvLivrosMais.AllowUserToResizeColumns = false;
            dgvLivrosMais.AllowUserToResizeRows = false;
            dgvLivrosMais.BackgroundColor = Color.LightGray;
            dgvLivrosMais.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvLivrosMais.Columns.AddRange(new DataGridViewColumn[] { Ranking, Titulo, Autor, Genero, ISBN, QuantidadeDeEmprestimos });
            dgvLivrosMais.Location = new Point(151, 156);
            dgvLivrosMais.Name = "dgvLivrosMais";
            dgvLivrosMais.ReadOnly = true;
            dgvLivrosMais.Size = new Size(773, 464);
            dgvLivrosMais.TabIndex = 0;
            // 
            // Ranking
            // 
            Ranking.HeaderText = "Ranking";
            Ranking.Name = "Ranking";
            Ranking.ReadOnly = true;
            // 
            // Titulo
            // 
            Titulo.HeaderText = "Título";
            Titulo.Name = "Titulo";
            Titulo.ReadOnly = true;
            Titulo.Width = 200;
            // 
            // Autor
            // 
            Autor.HeaderText = "Autor";
            Autor.Name = "Autor";
            Autor.ReadOnly = true;
            Autor.Width = 130;
            // 
            // Genero
            // 
            Genero.HeaderText = "Gênero";
            Genero.Name = "Genero";
            Genero.ReadOnly = true;
            // 
            // ISBN
            // 
            ISBN.HeaderText = "ISBN";
            ISBN.Name = "ISBN";
            ISBN.ReadOnly = true;
            // 
            // QuantidadeDeEmprestimos
            // 
            QuantidadeDeEmprestimos.HeaderText = "Quantidade de Empréstimos";
            QuantidadeDeEmprestimos.Name = "QuantidadeDeEmprestimos";
            QuantidadeDeEmprestimos.ReadOnly = true;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 45;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(412, 101);
            label2.Name = "label2";
            label2.Size = new Size(254, 30);
            label2.TabIndex = 47;
            label2.Text = "Livros Mais Emprestados";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 46;
            label1.Text = "VirtualBooks";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 57;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(457, 38);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // RelatorioLivrosMaisEmprestados
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvLivrosMais);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "RelatorioLivrosMaisEmprestados";
            Text = "RelatorioLivrosMaisEmprestados";
            Load += RelatorioLivrosMaisEmprestados_Load;
            ((System.ComponentModel.ISupportInitialize)dgvLivrosMais).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvLivrosMais;
        private DataGridViewTextBoxColumn Ranking;
        private DataGridViewTextBoxColumn Titulo;
        private DataGridViewTextBoxColumn Autor;
        private DataGridViewTextBoxColumn Genero;
        private DataGridViewTextBoxColumn ISBN;
        private DataGridViewTextBoxColumn QuantidadeDeEmprestimos;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label label12;
    }
}