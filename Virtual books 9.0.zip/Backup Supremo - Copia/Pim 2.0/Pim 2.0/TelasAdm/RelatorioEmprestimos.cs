﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class RelatorioEmprestimos : Form
    {
        public RelatorioEmprestimos()
        {
            InitializeComponent();
        }

        private void RelatorioEmprestimos_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controle = new ControleBibliotecario();
            var relatorio = controle.RelatorioEmprestimos();

            dgvEmprestimos.Rows.Clear();

            foreach (var item in relatorio)
            {
                int rowIndex = dgvEmprestimos.Rows.Add(
                    item.Nome,
                    item.Telefone,
                    item.Cpf,
                    item.Titulo,
                    item.Isbn,
                    item.DataEmprestimo,
                    item.DataDevolucaoReal,
                    item.DataDevolucaoPrevista,
                    item.Status,
                    item.Multa
                );

                var row = dgvEmprestimos.Rows[rowIndex];

                // Cor por status
                if (item.Status == "Devolvido")
                    row.Cells[8].Style.BackColor = Color.LightGreen;
                else if (item.Status == "Emprestado")
                    row.Cells[8].Style.BackColor = Color.LightGoldenrodYellow;

                // Cor por multa
                if (item.Multa != "Sem multa")
                {
                    if (decimal.TryParse(item.Multa, NumberStyles.Currency, CultureInfo.CurrentCulture, out decimal multaDecimal))
                    {
                        if (multaDecimal > 0)
                            row.Cells[9].Style.BackColor = Color.LightYellow;
                    }
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); // Executa uma vez

            string filtro = txtpesquisa.Text.Trim().ToLower();

            foreach (DataGridViewRow row in dgvEmprestimos.Rows)
            {
                if (row.IsNewRow) continue;

                if (string.IsNullOrEmpty(filtro))
                {
                    row.Visible = true; // Mostra tudo se vazio
                }
                else
                {
                    bool mostrar = row.Cells["nome"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["Cpf"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["Titulo"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["ISBN"].Value.ToString().ToLower().Contains(filtro);
                    row.Visible = mostrar;
                }
            }
        }

        private void txtpesquisa_TextChanged(object sender, EventArgs e)
        {
            timer1.Stop();   // reinicia o tempo a cada digitação
            timer1.Start();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }
    }
}
