﻿namespace Pim_2._0.TelasAdm
{
    partial class Devolver_Livros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Devolver_Livros));
            label1 = new Label();
            label2 = new Label();
            txtCPF = new TextBox();
            label4 = new Label();
            txtIsbn = new TextBox();
            label3 = new Label();
            btnDevolver = new Button();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 14;
            label1.Text = "VirtualBooks";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(119, 102);
            label2.Name = "label2";
            label2.Size = new Size(163, 30);
            label2.TabIndex = 15;
            label2.Text = "Devolver Livros";
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(60, 240);
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(275, 23);
            txtCPF.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(60, 217);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 25;
            label4.Text = "CPF :";
            // 
            // txtIsbn
            // 
            txtIsbn.Location = new Point(60, 172);
            txtIsbn.Name = "txtIsbn";
            txtIsbn.Size = new Size(275, 23);
            txtIsbn.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(60, 149);
            label3.Name = "label3";
            label3.Size = new Size(43, 20);
            label3.TabIndex = 23;
            label3.Text = "Isbn :";
            // 
            // btnDevolver
            // 
            btnDevolver.BackColor = SystemColors.ButtonHighlight;
            btnDevolver.Cursor = Cursors.Hand;
            btnDevolver.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDevolver.Location = new Point(98, 297);
            btnDevolver.Name = "btnDevolver";
            btnDevolver.Size = new Size(187, 29);
            btnDevolver.TabIndex = 34;
            btnDevolver.Text = "Devolver";
            btnDevolver.UseVisualStyleBackColor = false;
            btnDevolver.Click += btnDevolver_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(14, 16);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(41, 40);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 37;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label5);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 38;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Silver;
            label5.Location = new Point(119, 32);
            label5.Name = "label5";
            label5.Size = new Size(166, 37);
            label5.TabIndex = 10;
            label5.Text = "VirtualBooks";
            // 
            // Devolver_Livros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(380, 367);
            Controls.Add(panel1);
            Controls.Add(btnDevolver);
            Controls.Add(txtCPF);
            Controls.Add(label4);
            Controls.Add(txtIsbn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Devolver_Livros";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Devolver_Livros";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtCPF;
        private Label label4;
        private TextBox txtIsbn;
        private Label label3;
        private Button btnDevolver;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label5;
    }
}