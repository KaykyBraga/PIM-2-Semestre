﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class RelatorioLivrosMaisEmprestados : Form
    {
        public RelatorioLivrosMaisEmprestados()
        {
            InitializeComponent();
        }

        private void RelatorioLivrosMaisEmprestados_Load(object sender, EventArgs e)
        {

            ControleBibliotecario controle = new ControleBibliotecario();

            var relatorio = controle.RelatorioLivrosMaisEmprestados();

            foreach (var livro in relatorio)
            {
                dgvLivrosMais.Rows.Add(
                    livro.Ranking,
                    livro.Titulo,
                    livro.Autor,
                    livro.Genero,
                    livro.Isbn,
                    livro.QtdEmprestimos
                );
            }
        }

        

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }
    }
}
