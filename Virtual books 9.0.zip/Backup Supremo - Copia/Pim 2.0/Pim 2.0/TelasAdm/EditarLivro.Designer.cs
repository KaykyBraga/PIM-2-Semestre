﻿namespace Pim_2._0.TelasAdm
{
    partial class EditarLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditarLivro));
            txtIsbn = new TextBox();
            txtTitulo = new TextBox();
            txtAno = new TextBox();
            txtEditora = new TextBox();
            txtAutor = new TextBox();
            txtQuantidade = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            pictureBox1 = new PictureBox();
            label8 = new Label();
            label9 = new Label();
            btnAdicionar = new Button();
            label10 = new Label();
            txtLinkCapa = new TextBox();
            label11 = new Label();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            label12 = new Label();
            comboBoxGenero = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // txtIsbn
            // 
            txtIsbn.Location = new Point(99, 248);
            txtIsbn.Name = "txtIsbn";
            txtIsbn.Size = new Size(267, 23);
            txtIsbn.TabIndex = 0;
            // 
            // txtTitulo
            // 
            txtTitulo.Location = new Point(430, 248);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(267, 23);
            txtTitulo.TabIndex = 1;
            // 
            // txtAno
            // 
            txtAno.Location = new Point(99, 373);
            txtAno.Name = "txtAno";
            txtAno.Size = new Size(267, 23);
            txtAno.TabIndex = 2;
            // 
            // txtEditora
            // 
            txtEditora.Location = new Point(431, 311);
            txtEditora.Name = "txtEditora";
            txtEditora.Size = new Size(267, 23);
            txtEditora.TabIndex = 3;
            // 
            // txtAutor
            // 
            txtAutor.Location = new Point(99, 311);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(267, 23);
            txtAutor.TabIndex = 4;
            // 
            // txtQuantidade
            // 
            txtQuantidade.Location = new Point(99, 436);
            txtQuantidade.Name = "txtQuantidade";
            txtQuantidade.Size = new Size(267, 23);
            txtQuantidade.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(99, 220);
            label1.Name = "label1";
            label1.Size = new Size(43, 20);
            label1.TabIndex = 7;
            label1.Text = "Isbn :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(99, 283);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 8;
            label2.Text = "Autor :\r\n";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(431, 283);
            label3.Name = "label3";
            label3.Size = new Size(56, 20);
            label3.TabIndex = 9;
            label3.Text = "Editor :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(99, 350);
            label4.Name = "label4";
            label4.Size = new Size(43, 20);
            label4.TabIndex = 10;
            label4.Text = "Ano :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(431, 350);
            label5.Name = "label5";
            label5.Size = new Size(64, 20);
            label5.TabIndex = 11;
            label5.Text = "Genero :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(430, 220);
            label6.Name = "label6";
            label6.Size = new Size(54, 20);
            label6.TabIndex = 12;
            label6.Text = "Titulo :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(99, 413);
            label7.Name = "label7";
            label7.Size = new Size(94, 20);
            label7.TabIndex = 13;
            label7.Text = "Quantidade :";
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(768, 220);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(218, 285);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(462, 103);
            label8.Name = "label8";
            label8.Size = new Size(163, 30);
            label8.TabIndex = 16;
            label8.Text = "Adicionar Livro";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.Location = new Point(458, 38);
            label9.Name = "label9";
            label9.Size = new Size(166, 37);
            label9.TabIndex = 15;
            label9.Text = "VirtualBooks";
            // 
            // btnAdicionar
            // 
            btnAdicionar.BackColor = SystemColors.ButtonHighlight;
            btnAdicionar.Cursor = Cursors.Hand;
            btnAdicionar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAdicionar.Location = new Point(308, 504);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(187, 29);
            btnAdicionar.TabIndex = 31;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = false;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.Location = new Point(431, 413);
            label10.Name = "label10";
            label10.Size = new Size(84, 20);
            label10.TabIndex = 33;
            label10.Text = " Link Capa :";
            // 
            // txtLinkCapa
            // 
            txtLinkCapa.Location = new Point(431, 436);
            txtLinkCapa.Name = "txtLinkCapa";
            txtLinkCapa.Size = new Size(267, 23);
            txtLinkCapa.TabIndex = 34;
            txtLinkCapa.Leave += txtLinkCapa_Leave;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(828, 172);
            label11.Name = "label11";
            label11.Size = new Size(104, 20);
            label11.TabIndex = 35;
            label11.Text = "Capa do Livro";
            label11.Click += label11_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 38;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 39;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(457, 38);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // comboBoxGenero
            // 
            comboBoxGenero.FormattingEnabled = true;
            comboBoxGenero.Location = new Point(431, 373);
            comboBoxGenero.Name = "comboBoxGenero";
            comboBoxGenero.Size = new Size(266, 23);
            comboBoxGenero.TabIndex = 40;
            // 
            // EditarLivro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1079, 652);
            Controls.Add(comboBoxGenero);
            Controls.Add(panel1);
            Controls.Add(label11);
            Controls.Add(txtLinkCapa);
            Controls.Add(label10);
            Controls.Add(btnAdicionar);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(pictureBox1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtQuantidade);
            Controls.Add(txtAutor);
            Controls.Add(txtEditora);
            Controls.Add(txtAno);
            Controls.Add(txtTitulo);
            Controls.Add(txtIsbn);
            ForeColor = SystemColors.ActiveCaptionText;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "EditarLivro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditarLivro";
            Load += EditarLivro_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtIsbn;
        private TextBox txtTitulo;
        private TextBox txtAno;
        private TextBox txtEditora;
        private TextBox txtAutor;
        private TextBox txtQuantidade;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private PictureBox pictureBox1;
        private Label label8;
        private Label label9;
        private Button btnAdicionar;
        private Label label10;
        private TextBox txtLinkCapa;
        private Label label11;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label12;
        private ComboBox comboBoxGenero;
    }
}