﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class RelatorioUsuarios : Form
    {
        public RelatorioUsuarios()
        {
            InitializeComponent();
        }

        private void RelatorioUsuarios_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controle = new ControleBibliotecario();
            var relatorio = controle.RelatorioUsuarios();

            dgvUsuarios.Rows.Clear();

            foreach (var usuario in relatorio)
            {
                dgvUsuarios.Rows.Add(
                    usuario.Nome,
                    usuario.Telefone,
                    usuario.Cpf,
                    usuario.Email,
                    usuario.TotalEmprestimos
                );
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); // Executa uma vez

            string filtro = txtpesquisa.Text.Trim().ToLower();

            foreach (DataGridViewRow row in dgvUsuarios.Rows)
            {
                if (row.IsNewRow) continue;

                if (string.IsNullOrEmpty(filtro))
                {
                    row.Visible = true; // Mostra tudo se vazio
                }
                else
                {
                    bool mostrar = row.Cells["Nome"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["Cpf"].Value.ToString().ToLower().Contains(filtro);
                    row.Visible = mostrar;
                }
            }
        }

        private void txtpesquisa_TextChanged(object sender, EventArgs e)
        {
            timer1.Stop();   // reinicia o tempo a cada digitação
            timer1.Start();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void dgvUsuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
