﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;
using static System.Net.WebRequestMethods;

namespace Pim_2._0.TelasAdm
{
    public partial class EditarLivro : Form
    {
        public EditarLivro(string isbn, string titulo, string autor, string editora, string ano, string linkCapa)
        {
            InitializeComponent();
            txtIsbn.Text = isbn;
            txtTitulo.Text = titulo;
            txtAutor.Text = autor;
            txtEditora.Text = editora;
            txtAno.Text = ano;
            txtLinkCapa.Text = linkCapa;
        }
        private async void btnAdicionar_Click(object sender, EventArgs e)
        {
            ControleBibliotecario controleBibliotecario = new ControleBibliotecario();
            if (!string.IsNullOrEmpty(txtIsbn.Text.Trim()) && !string.IsNullOrEmpty(txtTitulo.Text.Trim()) && !string.IsNullOrEmpty(txtAutor.Text.Trim()) && !string.IsNullOrEmpty(txtEditora.Text.Trim()) && !string.IsNullOrEmpty(txtAno.Text.Trim()))
            {
                string generoSelecionado = comboBoxGenero.Text.Trim();
                bool valido = await controleBibliotecario.VerificarLinkImagemAsync(txtLinkCapa.Text.Trim());

                if (!valido)
                {
                    MessageBox.Show("O link da imagem deve terminar com .png, .jpg ou .jpeg.",
                                    "Link inválido",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning);
                    return;
                }

                if (!comboBoxGenero.Items.Contains(generoSelecionado))
                {
                    MessageBox.Show("Selecione um gênero válido da lista.", "Gênero inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                string isbn = txtIsbn.Text.Trim();
                string titulo = txtTitulo.Text.Trim();
                string autor = txtAutor.Text.Trim();
                string editora = txtEditora.Text.Trim();
                string ano = txtAno.Text.Trim();
                string qtdlivro = txtQuantidade.Text.Trim();
                string linkCapa = txtLinkCapa.Text.Trim();
                var adicionar = controleBibliotecario.AdicionarLivro(isbn, titulo, autor, editora, ano, generoSelecionado, qtdlivro, linkCapa, out string mensagem);
                if (adicionar)
                {
                    MessageBox.Show(mensagem, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Hide();
                    var principal = new Principal();
                    principal.FormClosed += (s, args) => Application.Exit();
                    principal.Show();
                }
                else
                {
                    MessageBox.Show(mensagem, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }


            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private async void EditarLivro_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controleBibliotecario = new ControleBibliotecario();
            string[] generos = new string[]
{
                "Ação", "Aventura", "Arte", "Arquitetura", "Autoajuda", "Autobiografia", "Biografia", "Chick-lit", "Ciência",
                "Ciência Política", "Ciência da Computação", "Ciência Espacial", "Ciência Social", "Clássico", "Comédia",
                "Conto", "Crônica", "Culinária", "Didático", "Direito", "Distopia", "Documentário", "Drama", "Ecologia",
                "Economia", "Educação", "Empreendedorismo", "Ensaio", "Erótico", "Espionagem", "Espiritualidade", "Esporte",
                "Estudo Bíblico", "Fantasia", "Fábula", "Ficção", "Ficção Científica", "Ficção Histórica", "Filosofia",
                "Folclore", "Guerra", "História", "História do Brasil", "História Geral", "História em Quadrinhos",
                "Horror", "Humor", "Infantil", "Infantojuvenil", "Investigativo", "Jovem Adulto", "Judaísmo", "LGBTQIA+",
                "Lendas", "Literatura Africana", "Literatura Asiática", "Literatura Brasileira", "Literatura Estrangeira",
                "Literatura Feminina", "Literatura Gótica", "Literatura Indígena", "Literatura Japonesa", "Literatura Medieval",
                "Literatura Negra", "Literatura Portuguesa", "Matemática", "Medicina", "Memórias", "Mitologia", "Misticismo",
                "Música", "Negócios", "New Adult", "Novela", "Paleontologia", "Paranormal", "Paródia", "Poesia", "Poesia Concreta",
                "Poesia Contemporânea", "Poesia Romântica", "Policial", "Política", "Psicologia", "Realismo", "Realismo Fantástico",
                "Religião", "Romance", "Romance Adolescente", "Romance Contemporâneo", "Romance Dark", "Romance de Época",
                "Romance Dramático", "Romance Erótico", "Romance Espírita", "Romance Histórico", "Romance Policial",
                "Romance Sobrenatural", "Satírico", "Saúde", "Sociologia", "Suspense", "Teatro", "Tecnologia", "Teologia",
                "Terror", "Thriller", "Turismo", "Utopia", "Viagem", "Western", "Young Adult"
            };
            comboBoxGenero.DropDownStyle = ComboBoxStyle.DropDown;
            comboBoxGenero.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBoxGenero.AutoCompleteSource = AutoCompleteSource.ListItems;
            comboBoxGenero.Items.AddRange(generos);
            bool valido = await controleBibliotecario.VerificarLinkImagemAsync(txtLinkCapa.Text.Trim());

            string caminhoPlaceholder = Path.Combine(Application.StartupPath, "Recursos", "placeholder.jpg");
            if (string.IsNullOrWhiteSpace(txtLinkCapa.Text.Trim()))
            {
                pictureBox1.Load(caminhoPlaceholder);
            }
            if (!valido)
            {
                pictureBox1.Load(caminhoPlaceholder);
            }
            else
            {
                pictureBox1.Load(txtLinkCapa.Text.Trim());
            }

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Adicionar_Livros adicionarLivros = new Adicionar_Livros();
            this.Hide();
            adicionarLivros.FormClosed += (s, args) => Application.Exit();
            adicionarLivros.Show();
        }

        private void txtLinkCapa_TextChanged(object sender, EventArgs e)
        {

        }

        private async void txtLinkCapa_Leave(object sender, EventArgs e)
        {
            string caminhoPlaceholder = Path.Combine(Application.StartupPath, "Recursos", "placeholder.jpg");
            string url = txtLinkCapa.Text.Trim();
            if (string.IsNullOrWhiteSpace(url))
            {
                pictureBox1.Load(caminhoPlaceholder);
                return;
            }
            ControleBibliotecario controleBibliotecario = new ControleBibliotecario();
            bool valido = await controleBibliotecario.VerificarLinkImagemAsync(url);

            if (!valido)
            {
                MessageBox.Show("O link da imagem deve terminar com .png, .jpg ou .jpeg.",
                                "Link inválido",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                txtLinkCapa.Focus();
                txtLinkCapa.SelectAll();
                pictureBox1.Load(caminhoPlaceholder);
            }
            else
            {
                pictureBox1.Load(txtLinkCapa.Text.Trim());
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}


