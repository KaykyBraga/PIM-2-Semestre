﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Adicionar_Livros : Form
    {
        public Adicionar_Livros()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            ControleBibliotecario buscar = new ControleBibliotecario();
            if (!string.IsNullOrEmpty(txtIsbn.Text.Trim()))
            {
                string isbn = txtIsbn.Text.Trim();
                var resultado = await buscar.BuscarLivro(isbn);

                if (!resultado.encontrado && !string.IsNullOrEmpty(resultado.mensagem))
                {
                    MessageBox.Show($"{resultado.mensagem}");
                    return;
                }

                EditarLivro editarLivro = new EditarLivro(isbn, resultado.titulo, resultado.autor, resultado.editora, resultado.ano, resultado.capaUrl);
                this.Hide();
                editarLivro.FormClosed += (s, args) => Application.Exit();
                editarLivro.Show();

            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {

        }

        private void btnVoltar_Click_1(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void Adicionar_Livros_Load(object sender, EventArgs e)
        {

        }
    }
}
