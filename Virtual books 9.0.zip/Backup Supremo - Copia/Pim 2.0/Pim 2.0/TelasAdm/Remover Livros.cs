﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Remover_Livros : Form
    {
        public Remover_Livros()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            ControleBibliotecario bibliotecario = new ControleBibliotecario();
            if (!string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
            {
                var remover = bibliotecario.RemoverEstoque(txtIsbn.Text.Trim(), txtQuantidade.Text.Trim(), out string mensagem);
                if (remover)
                {
                    MessageBox.Show(mensagem, "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show(mensagem, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }               
            }
            else
            {
                MessageBox.Show("preencha todos os campos.", "Avisso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }
    }
}
