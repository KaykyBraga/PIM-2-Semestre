﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class RelatorioEstoque : Form
    {

        public RelatorioEstoque()
        {
            InitializeComponent();
        }

        private void RelatorioEstoque_Load(object sender, EventArgs e)
        {
            ControleBibliotecario controle = new ControleBibliotecario();

            var relatorio = controle.RelatorioEstoque();

            foreach (var item in relatorio)
            {
                int rowIndex = dataGridViewEstoque.Rows.Add(
                    item.titulo,
                    item.autor,
                    item.genero,
                    item.quantidade,
                    item.isbn,
                    item.disponibilidade
                );

                DataGridViewRow row = dataGridViewEstoque.Rows[rowIndex];

                row.Cells[5].Style.BackColor = item.quantidade > 0
                    ? Color.LightGreen
                    : Color.Red;
            }

        }

        private void dataGridViewEstoque_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtpesquisa_TextChanged(object sender, EventArgs e)
        {
            timer1.Stop();   // reinicia o tempo a cada digitação
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            timer1.Stop(); // Executa uma vez

            string filtro = txtpesquisa.Text.Trim().ToLower();

            foreach (DataGridViewRow row in dataGridViewEstoque.Rows)
            {
                if (row.IsNewRow) continue;

                if (string.IsNullOrEmpty(filtro))
                {
                    row.Visible = true; // Mostra tudo se vazio
                }
                else
                {
                    bool mostrar = row.Cells["Titulo"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["Autor"].Value.ToString().ToLower().Contains(filtro) ||
                                   row.Cells["ISBN"].Value.ToString().ToLower().Contains(filtro);
                    row.Visible = mostrar;
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            this.Hide();
            principal.FormClosed += (s, args) => Application.Exit();
            principal.Show();
        }
    }
}
