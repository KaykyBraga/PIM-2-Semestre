﻿namespace Pim_2._0.TelasAdm
{
    partial class Emprestar_Livros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Emprestar_Livros));
            label1 = new Label();
            label2 = new Label();
            txtCPF = new TextBox();
            label4 = new Label();
            txtIsbn = new TextBox();
            label3 = new Label();
            btnEmprestar = new Button();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 13;
            label1.Text = "VirtualBooks";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(105, 101);
            label2.Name = "label2";
            label2.Size = new Size(175, 30);
            label2.TabIndex = 14;
            label2.Text = "Emprestar Livros";
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(54, 228);
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(275, 23);
            txtCPF.TabIndex = 22;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(54, 205);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 21;
            label4.Text = "CPF :";
            // 
            // txtIsbn
            // 
            txtIsbn.Location = new Point(54, 160);
            txtIsbn.Name = "txtIsbn";
            txtIsbn.Size = new Size(275, 23);
            txtIsbn.TabIndex = 20;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(54, 137);
            label3.Name = "label3";
            label3.Size = new Size(43, 20);
            label3.TabIndex = 19;
            label3.Text = "Isbn :";
            // 
            // btnEmprestar
            // 
            btnEmprestar.BackColor = SystemColors.ButtonHighlight;
            btnEmprestar.Cursor = Cursors.Hand;
            btnEmprestar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEmprestar.Location = new Point(93, 286);
            btnEmprestar.Name = "btnEmprestar";
            btnEmprestar.Size = new Size(187, 29);
            btnEmprestar.TabIndex = 32;
            btnEmprestar.Text = "Emprestar";
            btnEmprestar.UseVisualStyleBackColor = false;
            btnEmprestar.Click += btnEmprestar_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(41, 40);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 39;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 40;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(105, 32);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // Emprestar_Livros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(380, 367);
            Controls.Add(panel1);
            Controls.Add(btnEmprestar);
            Controls.Add(txtCPF);
            Controls.Add(label4);
            Controls.Add(txtIsbn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Emprestar_Livros";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Emprestar_Livros";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtCPF;
        private Label label4;
        private TextBox txtIsbn;
        private Label label3;
        private Button btnEmprestar;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label12;
    }
}