﻿namespace Pim_2._0.TelasAdm
{
    partial class RelatorioEstoque
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RelatorioEstoque));
            dataGridViewEstoque = new DataGridView();
            Titulo = new DataGridViewTextBoxColumn();
            Autor = new DataGridViewTextBoxColumn();
            Genero = new DataGridViewTextBoxColumn();
            Quantidade = new DataGridViewTextBoxColumn();
            ISBN = new DataGridViewTextBoxColumn();
            Disponibilidade = new DataGridViewTextBoxColumn();
            txtpesquisa = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridViewEstoque).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dataGridViewEstoque
            // 
            dataGridViewEstoque.AllowUserToAddRows = false;
            dataGridViewEstoque.AllowUserToDeleteRows = false;
            dataGridViewEstoque.AllowUserToResizeColumns = false;
            dataGridViewEstoque.AllowUserToResizeRows = false;
            dataGridViewEstoque.BackgroundColor = Color.LightGray;
            dataGridViewEstoque.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewEstoque.Columns.AddRange(new DataGridViewColumn[] { Titulo, Autor, Genero, Quantidade, ISBN, Disponibilidade });
            dataGridViewEstoque.Dock = DockStyle.Bottom;
            dataGridViewEstoque.Location = new Point(0, 198);
            dataGridViewEstoque.Name = "dataGridViewEstoque";
            dataGridViewEstoque.ReadOnly = true;
            dataGridViewEstoque.Size = new Size(1078, 454);
            dataGridViewEstoque.TabIndex = 0;
            dataGridViewEstoque.CellContentClick += dataGridViewEstoque_CellContentClick;
            // 
            // Titulo
            // 
            Titulo.HeaderText = "Título";
            Titulo.Name = "Titulo";
            Titulo.ReadOnly = true;
            Titulo.Width = 300;
            // 
            // Autor
            // 
            Autor.HeaderText = "Autor";
            Autor.Name = "Autor";
            Autor.ReadOnly = true;
            Autor.Width = 180;
            // 
            // Genero
            // 
            Genero.HeaderText = "Gênero";
            Genero.Name = "Genero";
            Genero.ReadOnly = true;
            Genero.Width = 180;
            // 
            // Quantidade
            // 
            Quantidade.HeaderText = "Quantidade";
            Quantidade.Name = "Quantidade";
            Quantidade.ReadOnly = true;
            // 
            // ISBN
            // 
            ISBN.HeaderText = "ISBN";
            ISBN.Name = "ISBN";
            ISBN.ReadOnly = true;
            ISBN.Width = 120;
            // 
            // Disponibilidade
            // 
            Disponibilidade.HeaderText = "Disponibilidade";
            Disponibilidade.Name = "Disponibilidade";
            Disponibilidade.ReadOnly = true;
            Disponibilidade.Width = 155;
            // 
            // txtpesquisa
            // 
            txtpesquisa.Location = new Point(12, 158);
            txtpesquisa.Name = "txtpesquisa";
            txtpesquisa.Size = new Size(228, 23);
            txtpesquisa.TabIndex = 1;
            txtpesquisa.TextChanged += txtpesquisa_TextChanged;
            // 
            // timer1
            // 
            timer1.Interval = 300;
            timer1.Tick += timer1_Tick;
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(14, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 44;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(496, 101);
            label2.Name = "label2";
            label2.Size = new Size(91, 30);
            label2.TabIndex = 49;
            label2.Text = "Estoque";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 48;
            label1.Text = "VirtualBooks";
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 56;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(457, 38);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // RelatorioEstoque
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(1078, 652);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtpesquisa);
            Controls.Add(dataGridViewEstoque);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "RelatorioEstoque";
            Text = "RelatorioEstoque";
            Load += RelatorioEstoque_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewEstoque).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridViewEstoque;
        private DataGridViewTextBoxColumn Titulo;
        private DataGridViewTextBoxColumn Autor;
        private DataGridViewTextBoxColumn Genero;
        private DataGridViewTextBoxColumn Quantidade;
        private DataGridViewTextBoxColumn ISBN;
        private DataGridViewTextBoxColumn Disponibilidade;
        private TextBox txtpesquisa;
        private System.Windows.Forms.Timer timer1;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Label label12;
    }
}