﻿namespace Pim_2._0.TelasAdm
{
    partial class QuantidadeLivros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuantidadeLivros));
            label1 = new Label();
            label3 = new Label();
            txtIsbn = new TextBox();
            label2 = new Label();
            txtQuantidade = new TextBox();
            label4 = new Label();
            btnAdicionar = new Button();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 12;
            label1.Text = "VirtualBooks";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(56, 151);
            label3.Name = "label3";
            label3.Size = new Size(43, 20);
            label3.TabIndex = 20;
            label3.Text = "Isbn :";
            // 
            // txtIsbn
            // 
            txtIsbn.Location = new Point(58, 175);
            txtIsbn.Name = "txtIsbn";
            txtIsbn.Size = new Size(275, 23);
            txtIsbn.TabIndex = 21;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(54, 215);
            label2.Name = "label2";
            label2.Size = new Size(94, 20);
            label2.TabIndex = 22;
            label2.Text = "Quantidade :";
            // 
            // txtQuantidade
            // 
            txtQuantidade.Location = new Point(56, 238);
            txtQuantidade.Name = "txtQuantidade";
            txtQuantidade.Size = new Size(275, 23);
            txtQuantidade.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(75, 104);
            label4.Name = "label4";
            label4.Size = new Size(232, 30);
            label4.TabIndex = 24;
            label4.Text = "Aumentar Quantidade";
            // 
            // btnAdicionar
            // 
            btnAdicionar.BackColor = SystemColors.ButtonHighlight;
            btnAdicionar.Location = new Point(97, 291);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(187, 29);
            btnAdicionar.TabIndex = 37;
            btnAdicionar.Text = "Adicionar";
            btnAdicionar.UseVisualStyleBackColor = false;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(11, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(67, 53);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 41;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkSlateBlue;
            panel1.Controls.Add(label12);
            panel1.Controls.Add(pictureBox2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1085, 87);
            panel1.TabIndex = 42;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Silver;
            label12.Location = new Point(108, 38);
            label12.Name = "label12";
            label12.Size = new Size(166, 37);
            label12.TabIndex = 10;
            label12.Text = "VirtualBooks";
            // 
            // QuantidadeLivros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightGray;
            ClientSize = new Size(380, 367);
            Controls.Add(panel1);
            Controls.Add(btnAdicionar);
            Controls.Add(label4);
            Controls.Add(txtQuantidade);
            Controls.Add(label2);
            Controls.Add(txtIsbn);
            Controls.Add(label3);
            Controls.Add(label1);
            Cursor = Cursors.Hand;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "QuantidadeLivros";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "QuantidadeLivros";
            Load += QuantidadeLivros_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label3;
        private TextBox txtIsbn;
        private Label label2;
        private TextBox txtQuantidade;
        private Label label4;
        private Button btnAdicionar;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label12;
    }
}