﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;
using Pim_2._0.TelasUsuario;

namespace Pim_2._0
{
    public partial class Tela_Login : Form
    {
        public Tela_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoginCadastro login = new LoginCadastro();
            if (!string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txtSenha.Text))
            {
                login.LoginUsuario(txtEmail.Text, txtSenha.Text, out int tela);
                switch (tela)
                {
                    case 1:
                        MessageBox.Show("Login realizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LogadoUsuario logadoUsuario = new LogadoUsuario();
                        logadoUsuario.Show();
                        this.Hide();
                        break;
                    case 2:
                        MessageBox.Show("Bem vindo Bibliotecario!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LogadoAdm logadoAdm = new LogadoAdm();
                        logadoAdm.Show();
                        this.Hide();
                        break;
                    case 3:
                        MessageBox.Show("Senha ou Email incorreto!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void chkMostrarSenha_CheckedChanged(object sender, EventArgs e)
        {
            if (chkMostrarSenha.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }

        private void label5_Click_2(object sender, EventArgs e)
        {
            TelaRedefinir telaRedefinir = new TelaRedefinir();
            telaRedefinir.Show();
            this.Hide();
        }
    }
}
