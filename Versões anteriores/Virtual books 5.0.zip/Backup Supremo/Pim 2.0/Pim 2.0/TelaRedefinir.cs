﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0
{
    public partial class TelaRedefinir : Form
    {
        public TelaRedefinir()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Tela_Login tela_Login = new Tela_Login();
            tela_Login.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            LoginCadastro login = new LoginCadastro();
            txbCPF.TextMaskFormat = MaskFormat.ExcludePromptAndLiterals;// Remove the mask


            if (!string.IsNullOrEmpty(txbCPF.Text) && !string.IsNullOrEmpty(txtEmail.Text) && !string.IsNullOrEmpty(txbTelefone.Text) && !string.IsNullOrEmpty(txtSenha.Text) && !string.IsNullOrEmpty(txtCSenha.Text))
            {
                login.RedefinirSenha(txbCPF.Text, txtEmail.Text, txbTelefone.Text, txtSenha.Text, txtCSenha.Text, out int erro);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Senha redefinida com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Tela_Login tela_Login = new Tela_Login();
                        tela_Login.Show();
                        this.Hide();
                        break;

                    case 1:
                        MessageBox.Show("As senhas não coincidem.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    case 2:
                        MessageBox.Show("Cpf, email ou telefone estão incorretos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                txtSenha.UseSystemPasswordChar = false;
                txtCSenha.UseSystemPasswordChar = false;
            }
            else
            {
                txtSenha.UseSystemPasswordChar = true;
                txtCSenha.UseSystemPasswordChar = true;
            }
        }

        private void txtSenha_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
