﻿namespace Pim_2._0
{
    partial class Tela_Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_Cadastro));
            label1 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            chkMostrarSenha = new CheckBox();
            txtCPF = new MaskedTextBox();
            txtTelefone = new MaskedTextBox();
            txtSenha = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            txtEmail = new TextBox();
            label5 = new Label();
            button1 = new Button();
            txtCSenha = new TextBox();
            txtNome = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 1;
            label1.Text = "VirtualBooks";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(chkMostrarSenha);
            panel1.Controls.Add(txtCPF);
            panel1.Controls.Add(txtTelefone);
            panel1.Controls.Add(txtSenha);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(txtCSenha);
            panel1.Controls.Add(txtNome);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(260, 100);
            panel1.Name = "panel1";
            panel1.Size = new Size(559, 504);
            panel1.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(20, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(87, 33);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // chkMostrarSenha
            // 
            chkMostrarSenha.AutoSize = true;
            chkMostrarSenha.Location = new Point(458, 359);
            chkMostrarSenha.Name = "chkMostrarSenha";
            chkMostrarSenha.Size = new Size(102, 19);
            chkMostrarSenha.TabIndex = 18;
            chkMostrarSenha.Text = "Mostrar Senha";
            chkMostrarSenha.UseVisualStyleBackColor = true;
            chkMostrarSenha.CheckedChanged += chkMostrarSenha_CheckedChanged;
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(110, 295);
            txtCPF.Mask = "000.000.000-00";
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(345, 23);
            txtCPF.TabIndex = 17;
            // 
            // txtTelefone
            // 
            txtTelefone.Location = new Point(110, 231);
            txtTelefone.Mask = "(00) 00000-0000";
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(345, 23);
            txtTelefone.TabIndex = 16;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(110, 356);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(345, 23);
            txtSenha.TabIndex = 15;
            txtSenha.UseSystemPasswordChar = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(110, 333);
            label8.Name = "label8";
            label8.Size = new Size(56, 20);
            label8.TabIndex = 14;
            label8.Text = "Senha :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(110, 264);
            label7.Name = "label7";
            label7.Size = new Size(40, 20);
            label7.TabIndex = 12;
            label7.Text = "CPF :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(110, 197);
            label6.Name = "label6";
            label6.Size = new Size(73, 20);
            label6.TabIndex = 11;
            label6.Text = "Telefone :";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(110, 157);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(345, 23);
            txtEmail.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(110, 134);
            label5.Name = "label5";
            label5.Size = new Size(53, 20);
            label5.TabIndex = 8;
            label5.Text = "Email :";
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(206, 455);
            button1.Name = "button1";
            button1.Size = new Size(140, 36);
            button1.TabIndex = 7;
            button1.Text = "Cadastrar";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // txtCSenha
            // 
            txtCSenha.Location = new Point(110, 420);
            txtCSenha.Name = "txtCSenha";
            txtCSenha.Size = new Size(345, 23);
            txtCSenha.TabIndex = 6;
            txtCSenha.UseSystemPasswordChar = true;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(110, 96);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(345, 23);
            txtNome.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(107, 397);
            label4.Name = "label4";
            label4.Size = new Size(126, 20);
            label4.TabIndex = 4;
            label4.Text = "Confirmar Senha :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(110, 73);
            label3.Name = "label3";
            label3.Size = new Size(127, 20);
            label3.TabIndex = 3;
            label3.Text = "Nome Completo :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(229, 22);
            label2.Name = "label2";
            label2.Size = new Size(102, 23);
            label2.TabIndex = 2;
            label2.Text = "CADASTRO";
            // 
            // Tela_Cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "Tela_Cadastro";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tela_Cadastro";
            Load += Tela_Cadastro_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private TextBox txtSenha;
        private Label label8;
        private TextBox textBox5;
        private Label label7;
        private Label label6;
        private TextBox textBox4;
        private TextBox txtEmail;
        private Label label5;
        private Button button1;
        private TextBox txtCSenha;
        private TextBox txtNome;
        private Label label4;
        private Label label3;
        private Label label2;
        private MaskedTextBox txtCPF;
        private MaskedTextBox txtTelefone;
        private CheckBox chkMostrarSenha;
        private PictureBox pictureBox1;
    }
}