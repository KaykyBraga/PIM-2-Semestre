﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Adicionar_Livros : Form
    {
        public Adicionar_Livros()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bibliotecario bibliotecario = new Bibliotecario();
            if(!string.IsNullOrEmpty(txtTitulo.Text) && !string.IsNullOrEmpty(txtAutor.Text) && !string.IsNullOrEmpty(txtEditora.Text) && !string.IsNullOrEmpty(txtAno.Text) && !string.IsNullOrEmpty(txtGenero.Text) && !string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
            {
                bibliotecario.AddLivro(txtIsbn.Text, txtTitulo.Text, txtAutor.Text, txtEditora.Text, txtAno.Text, txtGenero.Text, txtQuantidade.Text, out int erro);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Livro adicionado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;

                    case 1:
                        MessageBox.Show("Livro já existe.", "Aviso", MessageBoxButtons.OK , MessageBoxIcon.Warning);
                        break;

                    case 2:
                        MessageBox.Show("Erro na conversão de quantidade.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;

                    case 3:
                        MessageBox.Show("Erro ao adicionar livro.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;

                    default:

                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {

        }

        private void btnVoltar_Click_1(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Hide();
        }
    }
}
