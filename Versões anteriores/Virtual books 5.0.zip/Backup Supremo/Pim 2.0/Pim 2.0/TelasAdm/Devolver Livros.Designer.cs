﻿namespace Pim_2._0.TelasAdm
{
    partial class Devolver_Livros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtCPF = new TextBox();
            label4 = new Label();
            txtIsbn = new TextBox();
            label3 = new Label();
            btnDevolver = new Button();
            btnVoltar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 14;
            label1.Text = "VirtualBooks";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(461, 102);
            label2.Name = "label2";
            label2.Size = new Size(163, 30);
            label2.TabIndex = 15;
            label2.Text = "Devolver Livros";
            // 
            // txtCPF
            // 
            txtCPF.Location = new Point(416, 293);
            txtCPF.Name = "txtCPF";
            txtCPF.Size = new Size(275, 23);
            txtCPF.TabIndex = 26;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(416, 270);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 25;
            label4.Text = "CPF :";
            // 
            // txtIsbn
            // 
            txtIsbn.Location = new Point(416, 225);
            txtIsbn.Name = "txtIsbn";
            txtIsbn.Size = new Size(275, 23);
            txtIsbn.TabIndex = 24;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(416, 202);
            label3.Name = "label3";
            label3.Size = new Size(43, 20);
            label3.TabIndex = 23;
            label3.Text = "Isbn :";
            // 
            // btnDevolver
            // 
            btnDevolver.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnDevolver.Location = new Point(458, 364);
            btnDevolver.Name = "btnDevolver";
            btnDevolver.Size = new Size(187, 29);
            btnDevolver.TabIndex = 34;
            btnDevolver.Text = "Devolver";
            btnDevolver.UseVisualStyleBackColor = true;
            btnDevolver.Click += btnDevolver_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVoltar.Location = new Point(443, 437);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(215, 50);
            btnVoltar.TabIndex = 36;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // Devolver_Livros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1079, 652);
            Controls.Add(btnVoltar);
            Controls.Add(btnDevolver);
            Controls.Add(txtCPF);
            Controls.Add(label4);
            Controls.Add(txtIsbn);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Devolver_Livros";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Devolver_Livros";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtCPF;
        private Label label4;
        private TextBox txtIsbn;
        private Label label3;
        private Button btnDevolver;
        private Button btnVoltar;
    }
}