﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Devolver_Livros : Form
    {
        public Devolver_Livros()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Hide();
        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            Bibliotecario bibliotecario = new Bibliotecario();
            if(!string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtCPF.Text))
            {
                bibliotecario.DevolverLivro(txtIsbn.Text, txtCPF.Text, out int erro, out decimal multa);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Livro devolvido com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case 1:
                        MessageBox.Show("Emprestimo não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    case 2:
                        MessageBox.Show($"Livro devolvido com sucesso mas com multa de R${multa}.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    case 3:
                        MessageBox.Show("Nao foi possivel fazer a devolucao ", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;                      
                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
