﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class Remover_Livros : Form
    {
        public Remover_Livros()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Hide();
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            Bibliotecario bibliotecario = new Bibliotecario();
            if(!string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
            {
                bibliotecario.RemoverLivro(txtIsbn.Text, txtQuantidade.Text, out int erro);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("Livro removido com sucesso.", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;

                    case 1:

                        MessageBox.Show("Coloque somente numeros no campo quantidade.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 2:

                        MessageBox.Show("Quantidade a ser removida maior do que tem em estoque.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 3:
                        MessageBox.Show("Livro não encontrado.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;

                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("preencha todos os campos.", "Avisso", MessageBoxButtons.OK , MessageBoxIcon.Warning);
            }
        }
    }
}
