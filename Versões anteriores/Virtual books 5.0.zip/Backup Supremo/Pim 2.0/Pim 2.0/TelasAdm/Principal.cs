﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pim_2._0.TelasAdm
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            LogadoAdm logadoAdm = new LogadoAdm();
            logadoAdm.Show();
            this.Hide();
        }

        private void btnAddLivro_Click(object sender, EventArgs e)
        {
            Adicionar_Livros adicionarLivros = new Adicionar_Livros();
            adicionarLivros.Show();
            this.Hide();
        }

        private void btnRemoverLivro_Click(object sender, EventArgs e)
        {
            Remover_Livros removerLivros = new Remover_Livros();
            removerLivros.Show();
            this.Hide();
        }

        private void BtnDevolverLivro_Click(object sender, EventArgs e)
        {
            Devolver_Livros devolverLivros = new Devolver_Livros();
            devolverLivros.Show();
            this.Hide();
        }

        private void btnEmprestarLivro_Click(object sender, EventArgs e)
        {
            Emprestar_Livros emprestarLivros = new Emprestar_Livros();
            emprestarLivros.Show();
            this.Hide();
        }

        private void btnBuscarEmpréstimo_Click(object sender, EventArgs e)
        {
            Buscar_Empréstimo buscarEmpréstimo = new Buscar_Empréstimo();
            buscarEmpréstimo.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            QuantidadeLivros quantidadeLivros = new QuantidadeLivros();
            quantidadeLivros.Show();
            this.Hide();
        }

        private void btnRelatorio_Click(object sender, EventArgs e)
        {
            Relatorios relatorios = new Relatorios();
            relatorios.Show();
            this.Hide();
        }
    }
}
