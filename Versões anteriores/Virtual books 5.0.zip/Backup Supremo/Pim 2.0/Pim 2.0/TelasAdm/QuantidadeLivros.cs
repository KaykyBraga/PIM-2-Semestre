﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pim_2._0.Modelos;

namespace Pim_2._0.TelasAdm
{
    public partial class QuantidadeLivros : Form
    {
        public QuantidadeLivros()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Principal principal = new Principal();
            principal.Show();
            this.Hide();
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            Bibliotecario bibliotecario = new Bibliotecario();
            
            if (!string.IsNullOrEmpty(txtIsbn.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
            {
                bibliotecario.AumentarLivros(txtIsbn.Text, txtQuantidade.Text, out int erro);
                switch (erro)
                {
                    case 0:
                        MessageBox.Show("A quantindade do livro foi aumentada", "sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case 1:
                        MessageBox.Show("Adicione somente numeros a quantidade!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    case 2:
                        MessageBox.Show("livro nao encontrado!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                    default:
                        break;
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
