﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Usuario
    {
        public static int max_usuarios = 1000;
        public static int[] idUsuario = new int[max_usuarios];
        public static string[] nomeUsuario = new string[max_usuarios];
        public static string[] senhaUsuario = new string[max_usuarios];
        public static string[] emailUsuario = new string[max_usuarios];
        public static string[] telefoneUsuario = new string[max_usuarios];
        public static string[] cpfUsuario = new string[max_usuarios];
        public static int qtdUsuarios;
    }
}
