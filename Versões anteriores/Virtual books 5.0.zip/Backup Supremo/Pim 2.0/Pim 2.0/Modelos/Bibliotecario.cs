﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Bibliotecario
    {
        private static string email = "admin";

        public static string Email
        {
            get { return email; }

        }

        private static string senha = "admin";

        public static string Senha
        {
            get { return senha; }
        }

        public Bibliotecario() { }

        public void AddLivro(string isbn, string titulo, string autor, string editora, string ano, string genero, string qtdlivro, out int erro)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarLivros();
            SalvarDados salvar = new SalvarDados();
            int id = Livro.contadorLivros + 1;
            Verificador verificador = new Verificador();

            // verificar se o livro ja existe dentro dos arquivos
            if (verificador.VerificarLivroExistente(isbn, out int livro))
            {
                erro = 1; // livro já existe
                return;
            }

            int quantidade;
            bool converter = int.TryParse(qtdlivro, out quantidade);
            if (!converter)
            {
                erro = 2; // erro na conversao
                return;
            }

            Livro.idLivro[Livro.contadorLivros] = id;
            Livro.isbnLivro[Livro.contadorLivros] = isbn;
            Livro.tituloLivro[Livro.contadorLivros] = titulo;
            Livro.autorLivro[Livro.contadorLivros] = autor;
            Livro.editoraLivro[Livro.contadorLivros] = editora;
            Livro.anoLivro[Livro.contadorLivros] = ano;
            Livro.generoLivro[Livro.contadorLivros] = genero;
            Livro.qtdLivro[Livro.contadorLivros] = quantidade;
            Livro.contadorLivros++;
            salvar.SalvarLivros();
            erro = 0; // livro cadastrado com sucesso
            return;

        }

        public void AumentarLivros(string isbn, string qtdlivro, out int erro)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarLivros();
            SalvarDados salvar = new SalvarDados();
            Verificador verificador = new Verificador();

            int quantidade;
            bool converter = int.TryParse(qtdlivro, out quantidade);
            if (!converter)
            {
                erro = 1; // erro na conversao
                return;
            }

            if (verificador.VerificarLivroExistente(isbn, out int livro))
            {
                Livro.qtdLivro[livro] += quantidade;
                salvar.SalvarLivros();
                erro = 0; // livro cadastrado com sucesso
                return;

            }
            else
            {
                erro = 2; // livro não encontrado
                return;

            }

        }

        public void RemoverLivro(string isbn, string qtdlivro, out int erro)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarLivros();
            int quantidade;
            bool converter = int.TryParse(qtdlivro, out quantidade);
            if (!converter)
            {
                erro = 1;
                return;
            }

            for (int i = 0; i < Livro.contadorLivros; i++)
            {
                if (Livro.isbnLivro[i] == isbn)
                {
                    if (quantidade > Livro.qtdLivro[i])
                    {
                        erro = 2;
                        return;
                    }
                    else
                    {
                        Livro.qtdLivro[i] -= quantidade;
                        SalvarDados salvar = new SalvarDados();
                        salvar.SalvarLivros();
                        erro = 0;
                        return;
                    }
                }
            }
            erro = 3;
            return;
        }

        public void EmprestarLivro(string isbn, string cpf, out int erro)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarEmprestimos();
            carregar.CarregarUsuarios();
            carregar.CarregarLivros();

            bool usuarioEncontrado = false;
            int livrosEmprestados = 0;

            for (int i = 0; i < Usuario.qtdUsuarios; i++)
            {
                if (Usuario.cpfUsuario[i] == cpf)
                {
                    usuarioEncontrado = true;
                }
            }

            if (!usuarioEncontrado)
            {
                erro = 1; // usuário não encontrado
                return;
            }

            for (int i = 0; i < Emprestimos.contadorEmprestimos; i++)
            {
                if (Emprestimos.cpfUsuarioEmp[i] == cpf && Emprestimos.statusEmprestimo[i] == 0)
                {
                    livrosEmprestados++;
                }
            }

            if (livrosEmprestados >= 3)
            {
                erro = 2;
                return;
            }

            int indiceLivro = -1;
            for (int i = 0; i < Livro.contadorLivros; i++)
            {
                if (Livro.isbnLivro[i] == isbn && Livro.qtdLivro[i] > 0)
                {
                    indiceLivro = i;
                    break;
                }
            }
            if (indiceLivro == -1)
            {
                erro = 3; // Livro não encontrado
                return;
            }
            Livro.qtdLivro[indiceLivro]--;
            Livro.qtdVezesEmprestado[indiceLivro]++;
            Emprestimos.idEmprestimo[Emprestimos.contadorEmprestimos] = Emprestimos.contadorEmprestimos + 1;
            Emprestimos.cpfUsuarioEmp[Emprestimos.contadorEmprestimos] = cpf;
            Emprestimos.isbnLivroEmp[Emprestimos.contadorEmprestimos] = isbn;
            Emprestimos.dataEmprestimo[Emprestimos.contadorEmprestimos] = DateTime.Today;
            Emprestimos.dataDevolucaoPrevista[Emprestimos.contadorEmprestimos] = DateTime.Today.AddDays(7);
            Emprestimos.statusEmprestimo[Emprestimos.contadorEmprestimos] = 0; // 0 - ativo
            Emprestimos.contadorEmprestimos++;

            SalvarDados salvar = new SalvarDados();
            salvar.SalvarEmprestimos();
            salvar.SalvarLivros();
            erro = 0; // livro emprestado com sucesso
        }

        public void DevolverLivro(string isbn, string cpf, out int erro, out decimal multa)
        {
            CarregarDados carregar = new CarregarDados();
            carregar.CarregarEmprestimos();
            carregar.CarregarLivros();
            SalvarDados salvar = new SalvarDados();
            Emprestimos emprestimos = new Emprestimos();
            bool emprestimoEncontrado = false;
            DateTime dataDevolucaoReal = DateTime.Today;
            int indiceEmprestimo = -1;

            for (int i = 0; i < Emprestimos.contadorEmprestimos; i++)
            {
                if (Emprestimos.cpfUsuarioEmp[i] == cpf && Emprestimos.isbnLivroEmp[i] == isbn && Emprestimos.statusEmprestimo[i] == 0)
                {
                    indiceEmprestimo = i;
                    emprestimoEncontrado = true;
                    break;
                }
            }
            if (!emprestimoEncontrado)
            {
                erro = 1; // empréstimo não encontrado
                multa = 0;
                return;
            }

            emprestimos.VerSeEstaAtrasadoEMudarStatus(cpf, isbn, dataDevolucaoReal);


            if (Emprestimos.cpfUsuarioEmp[indiceEmprestimo] == cpf && Emprestimos.isbnLivroEmp[indiceEmprestimo] == isbn && Emprestimos.statusEmprestimo[indiceEmprestimo] == 0)
            {
                Emprestimos.dataDevolucaoReal[indiceEmprestimo] = DateTime.Today;
                Emprestimos.statusEmprestimo[indiceEmprestimo] = 1; // 1 - devolvido
                for (int j = 0; j < Livro.contadorLivros; j++)
                {
                    if (Livro.isbnLivro[j] == isbn)
                    {
                        Livro.qtdLivro[j]++;
                        break;
                    }
                }

                salvar.SalvarEmprestimos();
                salvar.SalvarLivros();
                erro = 0; // livro devolvido com sucesso
                multa = 0;
                return;
            }
            else if (Emprestimos.cpfUsuarioEmp[indiceEmprestimo] == cpf && Emprestimos.isbnLivroEmp[indiceEmprestimo] == isbn && Emprestimos.statusEmprestimo[indiceEmprestimo] == 2)
            {
                Emprestimos.dataDevolucaoReal[indiceEmprestimo] = DateTime.Today;
                Emprestimos.statusEmprestimo[indiceEmprestimo] = 1; // 1 - devolvido
                for (int j = 0; j < Livro.contadorLivros; j++)
                {
                    if (Livro.isbnLivro[j] == isbn)
                    {
                        Livro.qtdLivro[j]++;
                        break;
                    }
                }
                salvar.SalvarEmprestimos();
                salvar.SalvarLivros();
                erro = 2; // livro devolvido com sucesso, mas com multa
                multa = emprestimos.CalcularMulta(dataDevolucaoReal, Emprestimos.dataDevolucaoPrevista[indiceEmprestimo].Date);
                return;
            }

            erro = 3; // erro ao devolver o livro
            multa = 0;

        }
    }
}
