﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pim_2._0.Modelos
{
    internal class Emprestimos
    {
        public static int max_emprestimos = 1000;
        public static int[] idEmprestimo = new int[max_emprestimos];
        public static string[] cpfUsuarioEmp = new string[max_emprestimos];
        public static string[] isbnLivroEmp = new string[max_emprestimos];
        public static DateTime[] dataEmprestimo = new DateTime[max_emprestimos];
        public static DateTime[] dataDevolucaoPrevista = new DateTime[max_emprestimos];
        public static DateTime[] dataDevolucaoReal = new DateTime[max_emprestimos];
        public static int[] statusEmprestimo = new int[max_emprestimos]; // 0 - ativo, 1 - devolvido, 2 - atrasado
        public static int contadorEmprestimos = 0;

        private static int maximoEmprestimos = 3;

        public static int MaximoEmprestimo
        {
            get { return maximoEmprestimos; }
        }

        public Emprestimos() { }

        public void VerSeEstaAtrasadoEMudarStatus(string cpf, string isbn, DateTime dataDevolucaoReal)
        {
            CarregarDados carregarDados = new CarregarDados();
            carregarDados.CarregarEmprestimos();
            SalvarDados salvarDados = new SalvarDados();
            for (int i = 0; i < contadorEmprestimos; i++)
            {
                if (Emprestimos.cpfUsuarioEmp[i] == cpf && Emprestimos.isbnLivroEmp[i] == isbn)
                {
                    if (dataDevolucaoReal.Date > Emprestimos.dataDevolucaoPrevista[i].Date)
                    {
                        Emprestimos.statusEmprestimo[i] = 2; // 2 - atrasado
                        salvarDados.SalvarEmprestimos();
                        return;
                    }
                }
            }
            return;
        }

        public decimal CalcularMulta(DateTime dataDevolucaoReal, DateTime dataDevolucaoPresvista, decimal multaPorDia = 0.50m)
        {
            if (dataDevolucaoReal > dataDevolucaoPresvista)
            {
                TimeSpan diasAtraso = dataDevolucaoReal.Date - dataDevolucaoPresvista.Date;
                return (decimal)diasAtraso.Days * multaPorDia;
            }
            else
            {
                return 0m;
            }
        }
    }
}
