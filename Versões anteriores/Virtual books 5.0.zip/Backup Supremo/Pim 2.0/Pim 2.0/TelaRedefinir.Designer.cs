﻿namespace Pim_2._0
{
    partial class TelaRedefinir
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TelaRedefinir));
            label1 = new Label();
            panel1 = new Panel();
            txbTelefone = new MaskedTextBox();
            txbCPF = new MaskedTextBox();
            checkBox2 = new CheckBox();
            pictureBox1 = new PictureBox();
            btnRedefinirSenha = new Button();
            txtCSenha = new TextBox();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 9;
            label1.Text = "VirtualBooks";
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(txbTelefone);
            panel1.Controls.Add(txbCPF);
            panel1.Controls.Add(checkBox2);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnRedefinirSenha);
            panel1.Controls.Add(txtCSenha);
            panel1.Controls.Add(txtSenha);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Location = new Point(242, 140);
            panel1.Name = "panel1";
            panel1.Size = new Size(596, 462);
            panel1.TabIndex = 10;
            // 
            // txbTelefone
            // 
            txbTelefone.Location = new Point(137, 233);
            txbTelefone.Mask = "(00) 00000-0000";
            txbTelefone.Name = "txbTelefone";
            txbTelefone.Size = new Size(321, 23);
            txbTelefone.TabIndex = 25;
            // 
            // txbCPF
            // 
            txbCPF.Location = new Point(137, 106);
            txbCPF.Mask = "000.000.000-00";
            txbCPF.Name = "txbCPF";
            txbCPF.Size = new Size(321, 23);
            txbCPF.TabIndex = 24;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(464, 288);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(102, 19);
            checkBox2.TabIndex = 23;
            checkBox2.Text = "Mostrar Senha";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(22, 13);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(87, 33);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 21;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btnRedefinirSenha
            // 
            btnRedefinirSenha.BackColor = SystemColors.ButtonHighlight;
            btnRedefinirSenha.Location = new Point(231, 399);
            btnRedefinirSenha.Name = "btnRedefinirSenha";
            btnRedefinirSenha.Size = new Size(137, 32);
            btnRedefinirSenha.TabIndex = 14;
            btnRedefinirSenha.Text = "Redefinir Senha";
            btnRedefinirSenha.UseVisualStyleBackColor = false;
            btnRedefinirSenha.Click += button2_Click;
            // 
            // txtCSenha
            // 
            txtCSenha.Location = new Point(137, 347);
            txtCSenha.Name = "txtCSenha";
            txtCSenha.Size = new Size(321, 23);
            txtCSenha.TabIndex = 13;
            txtCSenha.UseSystemPasswordChar = true;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(137, 284);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(321, 23);
            txtSenha.TabIndex = 12;
            txtSenha.UseSystemPasswordChar = true;
            txtSenha.TextChanged += txtSenha_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(137, 163);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(321, 23);
            txtEmail.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(137, 324);
            label7.Name = "label7";
            label7.Size = new Size(126, 20);
            label7.TabIndex = 8;
            label7.Text = "Confirmar Senha :";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(137, 261);
            label6.Name = "label6";
            label6.Size = new Size(56, 20);
            label6.TabIndex = 7;
            label6.Text = "Senha :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(137, 204);
            label5.Name = "label5";
            label5.Size = new Size(73, 20);
            label5.TabIndex = 6;
            label5.Text = "Telefone :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(137, 140);
            label4.Name = "label4";
            label4.Size = new Size(53, 20);
            label4.TabIndex = 5;
            label4.Text = "Email :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(137, 78);
            label3.Name = "label3";
            label3.Size = new Size(40, 20);
            label3.TabIndex = 4;
            label3.Text = "CPF :";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(220, 23);
            label2.Name = "label2";
            label2.Size = new Size(157, 23);
            label2.TabIndex = 3;
            label2.Text = "REDEFINIR SENHA";
            label2.Click += label2_Click;
            // 
            // TelaRedefinir
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1079, 652);
            Controls.Add(panel1);
            Controls.Add(label1);
            Name = "TelaRedefinir";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "TelaRedefinir";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Label label2;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox txtCSenha;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private Button btnRedefinirSenha;
        private PictureBox pictureBox1;
        private CheckBox checkBox2;
        private MaskedTextBox txbCPF;
        private MaskedTextBox txbTelefone;
    }
}