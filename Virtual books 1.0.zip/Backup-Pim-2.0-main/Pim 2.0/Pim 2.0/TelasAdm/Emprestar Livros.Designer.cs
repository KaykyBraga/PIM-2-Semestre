﻿namespace Pim_2._0.TelasAdm
{
    partial class Emprestar_Livros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            label4 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            btnEmprestar = new Button();
            btnVoltar = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 13;
            label1.Text = "VirtualBooks";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(455, 103);
            label2.Name = "label2";
            label2.Size = new Size(175, 30);
            label2.TabIndex = 14;
            label2.Text = "Emprestar Livros";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(416, 293);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(275, 23);
            textBox2.TabIndex = 22;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(416, 270);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 21;
            label4.Text = "CPF :";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(416, 225);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(275, 23);
            textBox1.TabIndex = 20;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(416, 202);
            label3.Name = "label3";
            label3.Size = new Size(43, 20);
            label3.TabIndex = 19;
            label3.Text = "Isbn :";
            // 
            // btnEmprestar
            // 
            btnEmprestar.BackColor = SystemColors.ButtonHighlight;
            btnEmprestar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEmprestar.Location = new Point(455, 364);
            btnEmprestar.Name = "btnEmprestar";
            btnEmprestar.Size = new Size(189, 30);
            btnEmprestar.TabIndex = 32;
            btnEmprestar.Text = "Emprestar";
            btnEmprestar.UseVisualStyleBackColor = false;
            // 
            // btnVoltar
            // 
            btnVoltar.BackColor = SystemColors.ButtonHighlight;
            btnVoltar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVoltar.Location = new Point(442, 450);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(216, 52);
            btnVoltar.TabIndex = 34;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = false;
            btnVoltar.Click += button2_Click;
            // 
            // Emprestar_Livros
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1079, 652);
            Controls.Add(btnVoltar);
            Controls.Add(btnEmprestar);
            Controls.Add(textBox2);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Emprestar_Livros";
            Text = "Emprestar_Livros";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private Label label4;
        private TextBox textBox1;
        private Label label3;
        private Button btnEmprestar;
        private Button btnVoltar;
    }
}