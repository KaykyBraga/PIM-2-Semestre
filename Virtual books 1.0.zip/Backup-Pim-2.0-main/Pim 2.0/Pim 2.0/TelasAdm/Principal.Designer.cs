﻿namespace Pim_2._0.TelasAdm
{
    partial class Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnAddLivro = new Button();
            btnRemoverLivro = new Button();
            btnEmprestarLivro = new Button();
            BtnDevolverLivro = new Button();
            btnBuscarEmpréstimo = new Button();
            btnVoltar = new Button();
            label2 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(458, 38);
            label1.Name = "label1";
            label1.Size = new Size(166, 37);
            label1.TabIndex = 11;
            label1.Text = "VirtualBooks";
            // 
            // btnAddLivro
            // 
            btnAddLivro.BackColor = SystemColors.ButtonHighlight;
            btnAddLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnAddLivro.Location = new Point(188, 206);
            btnAddLivro.Name = "btnAddLivro";
            btnAddLivro.Size = new Size(222, 54);
            btnAddLivro.TabIndex = 12;
            btnAddLivro.Text = "Adicionar Livro";
            btnAddLivro.UseVisualStyleBackColor = false;
            btnAddLivro.Click += btnAddLivro_Click;
            // 
            // btnRemoverLivro
            // 
            btnRemoverLivro.BackColor = SystemColors.ButtonHighlight;
            btnRemoverLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnRemoverLivro.Location = new Point(432, 206);
            btnRemoverLivro.Name = "btnRemoverLivro";
            btnRemoverLivro.Size = new Size(222, 54);
            btnRemoverLivro.TabIndex = 13;
            btnRemoverLivro.Text = "Remover Livro";
            btnRemoverLivro.UseVisualStyleBackColor = false;
            btnRemoverLivro.Click += btnRemoverLivro_Click;
            // 
            // btnEmprestarLivro
            // 
            btnEmprestarLivro.BackColor = SystemColors.ButtonHighlight;
            btnEmprestarLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEmprestarLivro.Location = new Point(676, 206);
            btnEmprestarLivro.Name = "btnEmprestarLivro";
            btnEmprestarLivro.Size = new Size(222, 54);
            btnEmprestarLivro.TabIndex = 14;
            btnEmprestarLivro.Text = "Emprestar Livro";
            btnEmprestarLivro.UseVisualStyleBackColor = false;
            btnEmprestarLivro.Click += btnEmprestarLivro_Click;
            // 
            // BtnDevolverLivro
            // 
            BtnDevolverLivro.BackColor = SystemColors.ButtonHighlight;
            BtnDevolverLivro.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            BtnDevolverLivro.Location = new Point(301, 298);
            BtnDevolverLivro.Name = "BtnDevolverLivro";
            BtnDevolverLivro.Size = new Size(222, 54);
            BtnDevolverLivro.TabIndex = 15;
            BtnDevolverLivro.Text = "Devolver Livro";
            BtnDevolverLivro.UseVisualStyleBackColor = false;
            BtnDevolverLivro.Click += BtnDevolverLivro_Click;
            // 
            // btnBuscarEmpréstimo
            // 
            btnBuscarEmpréstimo.BackColor = SystemColors.ButtonHighlight;
            btnBuscarEmpréstimo.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnBuscarEmpréstimo.Location = new Point(557, 298);
            btnBuscarEmpréstimo.Name = "btnBuscarEmpréstimo";
            btnBuscarEmpréstimo.Size = new Size(222, 54);
            btnBuscarEmpréstimo.TabIndex = 16;
            btnBuscarEmpréstimo.Text = "Buscar Empréstimo";
            btnBuscarEmpréstimo.UseVisualStyleBackColor = false;
            btnBuscarEmpréstimo.Click += btnBuscarEmpréstimo_Click;
            // 
            // btnVoltar
            // 
            btnVoltar.BackColor = SystemColors.ButtonHighlight;
            btnVoltar.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnVoltar.Location = new Point(432, 464);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(222, 54);
            btnVoltar.TabIndex = 17;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = false;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(475, 103);
            label2.Name = "label2";
            label2.Size = new Size(137, 30);
            label2.TabIndex = 18;
            label2.Text = "Bibliotecário";
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1079, 652);
            Controls.Add(label2);
            Controls.Add(btnVoltar);
            Controls.Add(btnBuscarEmpréstimo);
            Controls.Add(BtnDevolverLivro);
            Controls.Add(btnEmprestarLivro);
            Controls.Add(btnRemoverLivro);
            Controls.Add(btnAddLivro);
            Controls.Add(label1);
            Name = "Principal";
            Text = "Principal";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnAddLivro;
        private Button btnRemoverLivro;
        private Button btnEmprestarLivro;
        private Button BtnDevolverLivro;
        private Button btnBuscarEmpréstimo;
        private Button btnVoltar;
        private Label label2;
    }
}